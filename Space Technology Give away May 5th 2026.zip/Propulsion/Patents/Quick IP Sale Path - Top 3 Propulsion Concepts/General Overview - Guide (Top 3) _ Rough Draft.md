# Quick IP Sale Guide: Top 3 Propulsion Concepts

## Objective
This guide provides a rapid, actionable path to selling or licensing the three highest‑value propulsion concepts with **minimal upfront effort**, **fast transaction timelines**, and **no need to seek external funding**. Each concept is matched to likely buyers, valuation ranges, and deal structures that facilitate quick closing.

---

## Summary of Top 3 Concepts

| Concept | TRL | Best‑Fit Buyer Category | Estimated Value Range (CAD) | Recommended Deal Structure |
|---------|-----|-------------------------|----------------------------|---------------------------|
| **6. Water-Based Dual-Mode Propulsion** | 6–7 | Small satellite propulsion companies; defense contractors; large aerospace primes | $500,000 – $3,000,000 (license) or $2M – $8M (outright sale) | Exclusive license with upfront payment + milestone royalties |
| **47. Golden Ratio PID Controller Tuning** | 6–7 | Industrial automation; aerospace control systems; software firms; drone manufacturers | $50,000 – $250,000 (license) or $200,000 – $800,000 (outright sale) | Non‑exclusive license with per‑unit royalty; or outright sale to a software company |
| **5. ABEP with Fractal Intake Geometry** | 5–6 | Satellite constellation operators; defense agencies; VLEO technology developers | $250,000 – $1,500,000 (license) or $1M – $5M (outright sale) | Exclusive license with milestone payments tied to flight demonstration |

---

## Concept 6: Water-Based Dual-Mode Propulsion

### 1. What You Are Selling
A propulsion system using **water as the sole propellant**, capable of switching between:
- **Chemical mode** (H₂/O₂ combustion) for high‑thrust maneuvers.
- **Electric mode** (water/oxygen plasma) for high‑efficiency station‑keeping.

**Key Features:**
- Shared electrolysis, feed, and power architecture.
- Eliminates need for separate xenon, hydrazine, or other propellants.
- Enables **ISRU** (use of lunar/asteroid water).

**IP Assets:**
- System architecture claims.
- Method claims for dual‑mode operation.
- Control algorithm claims.

### 2. Target Buyers

| Buyer Type | Examples | Why They Buy |
|------------|----------|--------------|
| **Small satellite propulsion companies** | Aliena, Phase Four, Apollo Fusion | Direct product line expansion; water is their focus area. |
| **Defense contractors** | Lockheed Martin, Northrop Grumman | Interest in low‑cost, non‑toxic, ISRU‑enabled propulsion for DoD satellites. |
| **Large aerospace primes** | Airbus Defence, Thales Alenia, MDA Space | Integration into satellite buses; green propulsion mandates. |
| **Space station logistics** | Voyager Space, Sierra Space | Water as cargo/resource for orbital infrastructure. |

### 3. Valuation Basis

| Factor | Assessment |
|--------|------------|
| **Market size** | Water propulsion market projected ~$1.5B by 2030 |
| **Competitors** | Aliena (Hydrocat) – electric only; General Galactic – chemical only; no dual‑mode product yet |
| **Readiness** | TRL 6–7; near‑flight demonstration |
| **Strategic value** | Enables ISRU; single‑propellant logistics; green alternative to hydrazine |

**Estimated License Value:**
- **Upfront payment:** $100,000 – $500,000
- **Milestone payments:** $100,000 – $500,000 upon flight demo
- **Running royalty:** 3–8% of net sales

**Estimated Outright Sale Value:**
- **$2,000,000 – $8,000,000** depending on development stage and supporting data

### 4. Quick Sale Process (30–60 Days)

| Step | Action | Time | Cost |
|------|--------|------|------|
| 1 | **Prepare one‑page teaser** – Describe technology, TRL, test results, market need. | 2 days | $0 |
| 2 | **Create confidential information memorandum (CIM)** – 5–10 pages with technical details, drawings, test data, IP status. | 1 week | $0 (self‑draft) |
| 3 | **Identify 5–10 target buyers** – Use LinkedIn, industry contacts, conference lists. | 3 days | $0 |
| 4 | **Send teaser under NDA** – Engage early discussions. | 1 week | $0 |
| 5 | **Share CIM with interested parties** – Follow up with call to explain technology. | 2 weeks | $0 |
| 6 | **Receive term sheets** – Negotiate exclusivity, upfront, royalties. | 2 weeks | $0 |
| 7 | **Execute agreement** – Use a standard IP license or assignment agreement (template available). | 1 week | Legal fees ($1,000–$5,000) if reviewed by counsel |

**Key to Speed:**
- Emphasize **flight heritage** or **near‑flight** status.
- Offer an **exclusive license** for a defined field (e.g., small satellites) to create urgency.
- Be flexible on deal structure (e.g., accept milestone payments instead of large upfront).

---

## Concept 47: Golden Ratio PID Controller Tuning

### 1. What You Are Selling
A **software‑based tuning method** for PID controllers that sets proportional, integral, and derivative gains according to the golden ratio: **Kp : Ki : Kd = φ : 1 : φ⁻¹**.

**Key Features:**
- Universal application (any PID‑controlled system).
- No hardware changes.
- Improves stability, reduces oscillations, increases response speed.
- Can be implemented as a software module, firmware update, or tuning tool.

**IP Assets:**
- Method claims for tuning PID gains using φ.
- System claims for a controller with gains set to φ ratios.
- Software claims for a tuning algorithm.

### 2. Target Buyers

| Buyer Type | Examples | Why They Buy |
|------------|----------|--------------|
| **Industrial automation software** | Siemens, Rockwell Automation, ABB | Add to control software libraries as a premium feature. |
| **Aerospace control systems** | Honeywell, Moog, Collins Aerospace | Enhance flight control systems, attitude control. |
| **Drone manufacturers** | DJI, Skydio, Wing | Improve stability and response in consumer/industrial drones. |
| **Robotics companies** | Boston Dynamics, Universal Robots | Optimize joint control and motion smoothness. |
| **Automotive** | Tesla, Bosch, Aptiv | Improve adaptive cruise, stability control. |

### 3. Valuation Basis

| Factor | Assessment |
|--------|------------|
| **Market size** | PID controllers are ubiquitous; billions of units in use |
| **Competitors** | Ziegler‑Nichols, Åström‑Hägglund, etc.; no φ‑based method in commercial use |
| **Readiness** | TRL 6–7; software‑only; easily integrated |
| **Strategic value** | Differentiator for control software providers; can be offered as a premium upgrade |

**Estimated License Value:**
- **Non‑exclusive license:** $10,000 – $50,000 upfront + 0.5–2% royalty on software sales or per‑unit fee ($0.10–$1.00 per unit)
- **Exclusive license:** $50,000 – $250,000 upfront + higher royalty

**Estimated Outright Sale Value:**
- **$200,000 – $800,000** depending on existing code, test data, and market reach

### 4. Quick Sale Process (30–45 Days)

| Step | Action | Time | Cost |
|------|--------|------|------|
| 1 | **Package as software module** – Write a simple Python/Matlab script implementing the tuning rule. | 1–2 days | $0 |
| 2 | **Create demonstration** – Show before/after response of a simulated or real system. | 1 week | $0 (simulation) |
| 3 | **Prepare marketing materials** – One‑page summary, video of demo, technical brief. | 2–3 days | $0 |
| 4 | **Target control software teams** – Identify product managers at target companies. | 3 days | $0 |
| 5 | **Offer non‑exclusive licenses** – Low upfront, low royalty to encourage adoption. | 2 weeks | $0 |
| 6 | **Sell outright to a software aggregator** – Companies like Altair, MathWorks may buy for integration into their toolboxes. | 2–4 weeks | Legal fees |

**Key to Speed:**
- Focus on **non‑exclusive licensing** – multiple buyers can be approached simultaneously.
- Provide a **trial version** or **demo code** to reduce buyer risk.
- Set a **low entry price** to encourage quick decisions.

---

## Concept 5: ABEP with Fractal Intake Geometry

### 1. What You Are Selling
An **air‑breathing electric propulsion (ABEP) intake** designed with a **fractal, self‑similar contour** using golden‑ratio scaling to maximize mass capture while minimizing drag, enabling persistent Very Low Earth Orbit (VLEO) operations.

**Key Features:**
- Fractal geometry (y(x) = y₀ Σ λ⁻ⁿ f_n(x), λ = φ⁻¹).
- Increases intake efficiency and thrust‑to‑drag ratio (TDR).
- Enables satellites to operate at 150–250 km without propellant resupply.
- Critical for high‑resolution imaging, low‑latency communications.

**IP Assets:**
- Structural claims for fractal intake geometry.
- Method claims for designing ABEP intakes using golden‑ratio scaling.
- System claims for ABEP satellite with fractal intake.

### 2. Target Buyers

| Buyer Type | Examples | Why They Buy |
|------------|----------|--------------|
| **ABEP developers** | DARPA Otter contractors (Redwire, Phase Four, Busek), ESA DISCOVERER partners | Direct integration into ABEP prototypes. |
| **Satellite constellation operators** | SpaceX (Starshield), Planet Labs, Capella Space | VLEO enables higher‑resolution imaging; ABEP eliminates propellant costs. |
| **Defense agencies** | DARPA, Air Force Research Lab, Canadian DND | Persistent surveillance from VLEO is a strategic capability. |
| **Satellite manufacturers** | Northrop Grumman, Airbus, Thales Alenia | Adding ABEP capability to satellite buses. |

### 3. Valuation Basis

| Factor | Assessment |
|--------|------------|
| **Market size** | VLEO satellite market projected $3–5B by 2030; ABEP is enabling technology |
| **Competitors** | ESA, DARPA Otter, Chinese programs – all developing ABEP, but fractal intake is unique |
| **Readiness** | TRL 5–6; validated in simulation (DSMC) and wind tunnel testing |
| **Strategic value** | Solves the drag problem for VLEO; differentiates ABEP system performance |

**Estimated License Value:**
- **Upfront payment:** $50,000 – $200,000
- **Milestone payments:** $100,000 – $300,000 upon flight demonstration
- **Running royalty:** 3–6% of ABEP system sales

**Estimated Outright Sale Value:**
- **$1,000,000 – $5,000,000** depending on test data and flight demonstration plans

### 4. Quick Sale Process (45–90 Days)

| Step | Action | Time | Cost |
|------|--------|------|------|
| 1 | **Compile simulation and test data** – DSMC results, wind tunnel data, CAD models. | 1 week | $0 (if data already exists) |
| 2 | **Create prototype or 3D model** – Physical model or high‑quality renderings. | 1 week | $0–$1,000 (3D printing) |
| 3 | **Prepare technical package** – 10–15 page document with design, performance, comparisons, IP claims. | 1 week | $0 |
| 4 | **Identify government program managers** – DARPA, ESA, AFRL, Canadian DND – ABEP is heavily government‑funded. | 3 days | $0 |
| 5 | **Approach prime contractors** – Redwire, Phase Four, Busek, Airbus. | 2 weeks | $0 |
| 6 | **Propose license with flight demo milestone** – Align with existing ABEP flight demonstration programs. | 2–4 weeks | $0 |
| 7 | **Execute agreement** – Use standard license with milestones tied to program funding. | 2 weeks | Legal fees |

**Key to Speed:**
- Target **government‑funded ABEP programs** – they have budgets and timelines.
- Offer to **co‑develop** the intake as part of an existing contract to reduce buyer risk.
- Emphasize **TDR improvement** as the primary performance metric – this is the critical figure for VLEO viability.

---

## Deal Structure Templates

### Exclusive License (Concept 6 and 5)
- **Term:** Duration of patent life (20 years from filing).
- **Territory:** Worldwide, or limited to North America / Europe.
- **Exclusivity:** Exclusive for a defined field (e.g., small satellites <1,000 kg).
- **Upfront:** $50,000 – $200,000.
- **Milestones:** $100,000 – $500,000 upon first flight demonstration.
- **Royalty:** 3–8% of net sales of licensed products.
- **Minimum royalties:** $10,000/year after first commercial sale.

### Non‑Exclusive License (Concept 47)
- **Term:** Perpetual.
- **Territory:** Worldwide.
- **Upfront:** $5,000 – $25,000.
- **Royalty:** $0.10 – $1.00 per unit, or 0.5–2% of software revenue.
- **No minimum royalties.**

### Outright Assignment (Any Concept)
- **Price:** Lump sum based on valuation.
- **Payment:** 50% at closing, 50% upon patent grant (or within 12 months).
- **Due diligence:** Buyer to conduct at their expense.
- **Representations:** Seller represents ownership and no prior encumbrances.

---

## Tools and Resources

| Task | Low‑Cost Resource |
|------|-------------------|
| **NDA template** | Canadian Bar Association template; CIPO website |
| **License agreement template** | AUTM (Association of University Technology Managers) sample agreements |
| **Patent status verification** | CIPO Canadian Patent Database (free) |
| **Buyer contacts** | LinkedIn Sales Navigator (trial); SpaceNews, Defense News directories |
| **Demo video** | OBS Studio (free); Loom (free tier) |
| **Legal review** | Law school clinics; patent agents offering fixed‑fee document review ($500–$2,000) |

---

## Final Checklist for Quick Sale

| Task | Completed |
|------|-----------|
| Prepare one‑page teaser for each concept | ☐ |
| Compile technical data and test results | ☐ |
| Create demo (simulation, video, or prototype) | ☐ |
| Identify 5–10 target buyers per concept | ☐ |
| Sign NDAs with interested parties | ☐ |
| Share CIM and schedule calls | ☐ |
| Receive and compare term sheets | ☐ |
| Select preferred buyer and negotiate | ☐ |
| Execute agreement | ☐ |
| Record assignment/license with CIPO (if required) | ☐ |

---

## Summary

| Concept | Target Buyer | Deal Structure | Timeframe | Expected Value |
|---------|--------------|----------------|-----------|----------------|
| Water-Based Dual-Mode Propulsion | Small satellite propulsion companies; defense primes | Exclusive license with milestone | 2–3 months | $500K–$3M license |
| Golden Ratio PID Controller | Industrial automation; aerospace control software | Non‑exclusive license; outright sale to software firm | 1–2 months | $50K–$250K license |
| ABEP Fractal Intake | ABEP developers; government program managers | Exclusive license with flight demo milestone | 2–4 months | $250K–$1.5M license |

**Total estimated return if all three transact within 6 months:** **$800,000 – $4,750,000** (licensing) or **$3,200,000 – $13,800,000** (outright sale).

**Next Step:** Prepare teasers and technical packages for each concept. Begin contacting target buyers within the next week.
