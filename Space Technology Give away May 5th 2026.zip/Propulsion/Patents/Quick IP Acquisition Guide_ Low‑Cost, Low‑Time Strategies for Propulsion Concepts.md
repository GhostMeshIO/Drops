# Quick IP Acquisition Guide: Low‑Cost, Low‑Time Strategies for Propulsion Concepts

## Objective
Secure intellectual property rights for your advanced propulsion concepts with **minimal upfront fees**, **least amount of time**, and **no need to seek external funding**. This guide outlines lean, practical strategies to obtain early priority dates and build a patent portfolio while deferring major costs.

---

## 1. Leverage Provisional‑Style Canadian Filings

Canada does not have a formal “provisional” application, but you can achieve a similar result by filing a **complete application without claims**. This gives you a filing date and a 3‑month window to add claims—a low‑cost, low‑effort way to secure priority.

### Steps:
1. **Prepare a description** – Write a detailed technical description of your invention. Use clear language, explain how it works, include equations (e.g., the fractal metric, coherence evolution equation) and diagrams (hand‑drawn is acceptable).
2. **Prepare drawings** – Simple line drawings that illustrate the structure or method.
3. **File online via CIPO’s website** – Submit the description, drawings, and a request for a patent. **Do not include claims** (they can be added later).
4. **Pay the filing fee** – **$424.54** (small entity). This is the only cost at this stage.
5. **Within 3 months** – File your claims (you can prepare them yourself or with limited agent help). No additional government fee for adding claims.

**Total upfront cost:** ~$425 per application  
**Time to filing date:** 1–2 days to prepare, same day to file

---

## 2. Consolidate Multiple Concepts into One Application

If your concepts are related (e.g., various control algorithms for plasma thrusters), you can file **one application** covering several inventions. This saves filing, examination, and maintenance fees.

### How:
- Draft a single description that covers the family of ideas.
- Use a **unity of invention** argument—e.g., all relate to “plasma control using coherence evolution.”
- File with broad claims covering the core concept and dependent claims for specific variants.

**Savings:** Instead of 10 applications, you might file 3–4, reducing upfront costs by 60–70%.

---

## 3. Use Small Entity Status

Both CIPO and USPTO offer reduced fees for **small entities** (≤50 employees, or a university). Ensure you qualify and claim it.

| Fee | Standard | Small Entity |
|-----|----------|--------------|
| Filing | $424.54 | $424.54 (same) |
| Examination | $816.00 | $816.00 (same) |
| Maintenance (year 2) | $100 | $100 |

*Note:* CIPO’s small entity fee is the same as standard; the main benefit is in other jurisdictions (e.g., USPTO micro entity). Still, always claim small entity where available.

---

## 4. Request Accelerated Examination (Green Technology)

If your invention relates to **environmentally beneficial technology** (e.g., water‑based propulsion, ABEP, fusion), you can request **accelerated examination** at no additional government fee. This can reduce the time to grant from years to months.

### How:
- When filing, indicate that the application relates to green technology.
- Submit a simple statement explaining the environmental benefit.
- Examination will start immediately (no need to wait in queue).

**Benefit:** Faster grant, earlier enforceability, without extra cost.

---

## 5. Consider the US Provisional Route (Even Lower Upfront Cost)

For inventors who can later file a Canadian application within 12 months, a **US provisional application** offers an extremely low‑cost way to secure a priority date.

| Cost (USPTO micro entity) | Fee |
|---------------------------|-----|
| Provisional filing fee | $70 |
| No claims required | – |
| No examination | – |

### Steps:
1. Write a provisional specification (same as a description, but no claims).
2. File online via USPTO’s EFS‑Web (requires a US address or a registered US agent; you can use a mail forwarding service or a low‑cost agent).
3. Within 12 months, file a Canadian standard application claiming priority to the US provisional.

**Total upfront cost:** ~$70 (US) + any agent fees (if any).  
**Time:** Same day filing.

*Downside:* You will need to file the Canadian application later, but that cost is deferred by up to 12 months.

---

## 6. Write Your Own Application (Pro Se Filing)

You are legally allowed to file a patent application without a registered agent. This eliminates professional drafting fees. While not recommended for complex technologies, it is possible for a skilled engineer to write a basic description and claims.

### Tips for Self‑Drafting:
- Follow CIPO’s *Guide to Patents* for format.
- Use plain language; describe the invention in detail.
- Provide at least one concrete example of how it works.
- Include drawings (even simple sketches).
- Draft claims in clear, single‑sentence form.

**Risk:** Poorly drafted claims may be narrowed or rejected, reducing protection. However, you can always hire an agent later to amend (with additional cost).

---

## 7. Use Defensive Publication as an Alternative

If the goal is simply to prevent others from patenting the idea (rather than obtaining exclusive rights), you can **publish** your invention. This creates prior art, blocking competitors, at **zero cost**.

### Options:
- **Post on a public website** (e.g., your own site, arXiv) with a clear date.
- **Use CIPO’s “Open for Public Inspection”** – once a patent application is published (18 months after filing), it becomes prior art even if you abandon the application.
- **Defensive publication platforms** like *Research Disclosure* or *IP.com* (small fee).

**Cost:** $0 to a few hundred dollars.

---

## 8. Leverage Trade Secrets Where Appropriate

For algorithms, software, or manufacturing processes that are not easily reverse‑engineered, **trade secret protection** can be more cost‑effective than patents.

### Advantages:
- No filing fees, no maintenance fees.
- No public disclosure.
- Protection lasts indefinitely if kept confidential.

### Requirements:
- Implement strict internal confidentiality (NDAs, access controls).
- Do not disclose the secret publicly.

*Note:* Trade secrets are not suitable for products that will be sold or used publicly where the secret could be discovered.

---

## 9. Sample Lean Filing Strategy for the Top 10 Concepts

| Step | Action | Cost | Timeline |
|------|--------|------|----------|
| 1 | Group concepts into 3 families (e.g., propulsion systems, control algorithms, materials) | $0 | 1 week |
| 2 | Write one description per family, including key equations and drawings (self‑drafted) | $0 | 2–3 weeks |
| 3 | File each family as a Canadian application **without claims** | $424.54 × 3 = $1,273.62 | Same day |
| 4 | Within 3 months, add claims (self‑drafted) | $0 | 3 months |
| 5 | Request green tech accelerated examination for each | $0 | Immediately after claims added |
| 6 | Pay maintenance fees only when due (starting year 2) | $100 per application per year | Deferred |

**Total upfront cash outlay:** **~$1,300** for 3 applications covering all 10 concepts.  
**Time to priority date:** 2–4 weeks (preparation + filing).

---

## 10. Important Considerations

- **Your own prior disclosure:** If you have already publicly disclosed the invention, you have only **12 months from that disclosure** to file in Canada. Act quickly.
- **Confidentiality:** Before filing, keep your invention confidential. Avoid public presentations or publications.
- **Patent Agent:** While not required, a good agent can save money in the long run by avoiding costly amendments. Consider a **fixed‑fee** arrangement for a limited scope of work (e.g., just drafting the claims) to keep costs predictable.

---

## Conclusion

You can secure priority rights for your advanced propulsion concepts with **less than $1,500 upfront** by:
- Filing Canadian applications without claims,
- Grouping related concepts,
- Self‑drafting the description,
- Using small entity status,
- Requesting green tech accelerated examination,
- Deferring professional fees until later (if needed).

This lean approach gives you a **priority date**, a pending application, and up to 12 months to seek funding or decide on further international filing—all without requiring external investment.
