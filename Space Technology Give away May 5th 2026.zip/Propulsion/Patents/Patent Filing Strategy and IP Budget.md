# Filing Strategy & IP Budget for Top Priority Concepts

## 1. Filing Strategy Overview

The goal is to secure earliest possible priority dates for the 10 Tier‑1 concepts while managing costs and aligning with business goals. The following strategy balances immediate protection, optionality for international expansion, and staged investment.

### 1.1 Selection of Top Concepts

Based on the prior art search and commercial priority, the following 10 concepts are recommended for immediate filing (Tier 1):

| # | Concept | Filing Priority |
|---|---------|-----------------|
| 6 | Water-Based Dual-Mode Propulsion | Highest |
| 47 | Golden Ratio PID Controller Tuning | Highest |
| 5 | ABEP with Fractal Intake Geometry | High |
| 30 | Network Coherence Synchronizer | High |
| 23 | Recursive Causal Discovery for Anomaly Prediction | High |
| 27 | Semantic Kalman Filter | Medium-High |
| 29 | Coherence Evolution Controller | Medium-High |
| 31 | Fractal Turbulence Simulator | Medium |
| 17 | Water-Based Dual-Use Thermal Management | Medium |
| 2 | Fractal Metric Magnetic Coil Design | Medium |

### 1.2 Application Type Options

#### Option A: Direct Canadian Standard Application (Recommended)
- **Action:** File a complete standard application (specification, claims, drawings) with CIPO.
- **Advantage:** Establishes a Canadian filing date immediately; no subsequent conversion needed.
- **Disadvantage:** Full drafting cost upfront; cannot later claim priority from a provisional if not filed within 12 months.

#### Option B: US Provisional + Canadian Priority Claim (Optional)
- **Action:** File a US provisional application first (less formal, lower initial cost) to secure a priority date. Within 12 months, file a Canadian standard application claiming priority to the US provisional.
- **Advantage:** Defer full drafting costs by up to 12 months; allows testing market or securing funding before committing to full national filing.
- **Disadvantage:** Additional cost for US provisional filing and for claiming priority.

**Recommendation:** For the top 3–5 concepts with highest commercial urgency, file **direct Canadian standard applications** to get granted patents faster. For the remaining concepts, consider **US provisional first** to spread costs and allow refinement of claims based on initial market feedback.

---

## 2. Filing Timeline

We propose a **staged filing** over 12 months to manage cash flow and legal resources.

| Phase | Timing | Concepts | Action |
|-------|--------|----------|--------|
| Phase 1 | Month 1–3 | 1–3 (Water-Based Dual-Mode, Golden Ratio PID, ABEP Fractal Intake) | Direct Canadian standard filing |
| Phase 2 | Month 4–6 | 4–6 (Network Coherence, Recursive Causal, Semantic Kalman) | US provisional filing |
| Phase 3 | Month 7–9 | 7–9 (Coherence Evolution, Fractal Turbulence, Dual-Use Thermal) | US provisional filing |
| Phase 4 | Month 10–12 | 10 (Fractal Metric Coil) + optional PCT for key concepts | US provisional filing + consider PCT for international expansion |

Within 12 months of each US provisional, a Canadian standard application (and optionally PCT) must be filed to claim priority.

---

## 3. IP Budget

All costs are estimated in **Canadian Dollars (CAD)** and assume **small entity status** (applicant with ≤50 employees or a university). Professional fees are based on average rates for registered patent agents in Canada with expertise in aerospace/physics/software. Actual costs may vary.

### 3.1 Cost Components

| Cost Item | Per Application (CAD) | Notes |
|-----------|-----------------------|-------|
| **Drafting (standard application)** | $6,000 – $12,000 | Varies with complexity; software/algorithms may be lower, complex plasma systems higher. |
| **Filing Fee (CIPO)** | $424.54 | Standard application, small entity. |
| **Examination Request Fee** | $816.00 | Small entity, due within 4 years of filing. |
| **Maintenance Fees (Years 2–10)** | $1,550 – $2,250 | Cumulative over 10 years (see breakdown below). |
| **Final Fee (upon allowance)** | $306.00 | Small entity. |
| **US Provisional (optional)** | $2,000 – $4,000 | Drafting only; no CIPO fees. |
| **PCT Filing (optional)** | $8,000 – $12,000 | For international route; includes drafting, filing, search fee. |

### 3.2 Maintenance Fee Schedule (CAD, Small Entity)

| Year (from filing) | Fee | Cumulative (per patent) |
|-------------------|-----|-------------------------|
| 2nd | $100 | $100 |
| 3rd | $100 | $200 |
| 4th | $100 | $300 |
| 5th | $100 | $400 |
| 6th | $150 | $550 |
| 7th | $150 | $700 |
| 8th | $150 | $850 |
| 9th | $150 | $1,000 |
| 10th–19th (each) | $450 | $4,500 (for 10 years) |

### 3.3 Estimated Budget for 10 Concepts

#### Scenario A: All 10 filed as direct Canadian standard applications

| Cost Element | Per Concept | Total (10) |
|--------------|-------------|------------|
| Drafting | $8,000 (avg) | $80,000 |
| Filing Fee | $424.54 | $4,245 |
| Examination Request | $816.00 | $8,160 |
| Final Fee (when allowed) | $306.00 | $3,060 |
| Maintenance (first 10 years) | $1,900 (approx) | $19,000 |
| **Total** | **$11,446** | **$114,465** |

**Notes:**
- Professional drafting fees dominate the budget.
- Maintenance fees are spread over 10 years; only $400–$1,000 per patent is due in the first 5 years.
- Examination fees are due only when requested (up to 4 years from filing), allowing cost deferral.

#### Scenario B: 3 direct Canadian + 7 US provisional first

| Concept Group | Direct Canadian (3) | US Provisional (7) | Canadian Priority Filing (within 12 months of each provisional) |
|---------------|---------------------|---------------------|----------------------------------------------------------------|
| Drafting | $24,000 | $21,000 (7 × $3,000) | $56,000 (7 × $8,000) |
| Filing Fees | $1,274 (3 × $425) | $0 (no CIPO fee) | $2,971 (7 × $425) |
| Examination (all 10) | $2,448 (3 × $816) | – | $5,712 (7 × $816) |
| Final Fees (10) | $918 (3 × $306) | – | $2,142 (7 × $306) |
| Maintenance (10) | $5,700 (3 × $1,900) | – | $13,300 (7 × $1,900) |
| **Total** | **$34,340** | **$21,000** | **$80,125** |
| **Combined Total** | | | **$135,465** |

**Comparison:** Scenario B costs about $21,000 more than Scenario A but defers ~$56,000 of drafting costs by 12 months, which can be advantageous for cash flow. The choice depends on available capital and desire for earliest possible Canadian grant.

#### Scenario C: Reduced portfolio – file only top 5 concepts first

If budget is constrained, filing the top 5 concepts (as per priority ranking) is recommended:

| Concepts | Drafting | Filing | Exam | Final | Maint (10y) | Total |
|----------|----------|-------|------|-------|-------------|-------|
| 5 direct Canadian | $40,000 | $2,123 | $4,080 | $1,530 | $9,500 | **$57,233** |

This keeps initial outlay under $60,000 while securing the highest‑value assets.

---

## 4. Recommended Action Plan

### 4.1 Immediate (Next 3 Months)
- **Engage a patent agent** with expertise in aerospace, software, and plasma physics.
- **File Phase 1 concepts** as direct Canadian standard applications to secure earliest priority dates.
- **Begin drafting Phase 2 and 3 concepts** for US provisional filings.

### 4.2 Within 6 Months
- **File US provisional applications** for Phase 2 concepts.
- **Consider accelerated examination** for green technologies (Water-Based Dual-Mode, ABEP) to obtain granted patents faster.

### 4.3 Within 12 Months
- **File Canadian standard applications** claiming priority from the US provisionals for Phase 2–4 concepts.
- **Evaluate international expansion:** For key concepts, file PCT applications to preserve rights in Europe, US, Japan, etc. Budget an additional $10,000–$15,000 per PCT.

### 4.4 Ongoing
- **Monitor prior art** and adjust claims during prosecution.
- **Pay maintenance fees** on schedule to avoid abandonment.
- **Review portfolio annually** to decide which applications to continue (drop low‑value concepts to save costs).

---

## 5. Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Prior art emerges | File early to establish priority; conduct periodic prior art monitoring. |
| Budget overruns | Use staged filing; consider provisional first for non‑urgent concepts; cap drafting fees with fixed‑fee arrangements. |
| Examination delays | Request accelerated examination for key concepts (green tech). |
| International competition | File PCT within 12 months of earliest priority to preserve global rights. |

---

## 6. Summary of Estimated Costs

| Scenario | Initial 12‑Month Cost | Total Over 10 Years (incl. maintenance) |
|----------|-----------------------|------------------------------------------|
| 10 direct Canadian | $80,000–$100,000 | $115,000–$135,000 |
| 3 direct + 7 provisional | $40,000–$60,000 (first 12 months) | $135,000–$155,000 |
| Top 5 direct | $40,000–$50,000 | $55,000–$65,000 |

*Note: These estimates assume small entity status and no unexpected prosecution complexity.*

---

**Next Step:** Select the filing scenario that aligns with your budget and strategic goals. Engage a patent agent to begin drafting the highest‑priority applications immediately.
