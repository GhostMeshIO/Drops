# Funding Sources and Development Pathways

The 56 patent concepts described in this portfolio span a wide range of technology readiness levels (TRL 2–7) and address markets that are actively supported by government, corporate, and private funding mechanisms. This section provides a comprehensive overview of available funding sources, organized by geography and program type, along with strategic recommendations for accelerating development and maximizing IP value.

---

## I. Canadian Government Funding Programs

Canada offers a robust ecosystem of non‑repayable grants, repayable contributions, and tax incentives specifically designed to support early‑stage technology development, prototype testing, and commercialization.

| Program | Description | Relevance to Portfolio | Contact / Action |
|---------|-------------|------------------------|------------------|
| **NRC‑IRAP (Industrial Research Assistance Program)** | Non‑repayable grants (up to $500 K per project) for technology development, including simulation, prototyping, and field testing. Supports TRL advancement and IP development. | All concepts; particularly suited for TRL 3–5 propulsion systems (e.g., Water‑Based Dual‑Mode, ABEP intake) and AI algorithms. | Local Industrial Technology Advisor (ITA) via irap.nrc.gc.ca |
| **CSA FAST (Flights and Fieldwork for the Advancement of Science and Technology)** | Provides parabolic flight, sounding rocket, and suborbital platform access for space technology validation. | High‑value for ABEP (Concept 5), plasma diagnostics (Concepts 1, 34), and water propulsion (Concept 6) that require microgravity or VLEO environment testing. | asc‑csa.gc.ca/fast – annual calls |
| **CSA Space Technology Development Program (STDP)** | Grants (up to $500 K) for development of space technologies with commercial or mission potential. Funds hardware development, environmental testing, and technology demonstration. | Direct fit for all propulsion concepts; STDP has funded water‑based thrusters and ABEP components in the past. | asc‑csa.gc.ca – solicitations published yearly |
| **NBIF (New Brunswick Innovation Foundation)** | Proof of Concept Program: up to $100 K non‑repayable for early‑stage commercialization. Venture Fund: equity investment up to $500 K for later‑stage companies. | Strong fit for Atlantic Canada‑based entities developing these technologies; can bridge funding gaps before licensing or acquisition. | nbif.ca – Rolling intake |
| **ACOA Business Development Program (BDP)** | Up to 50% cost‑share (non‑repayable for smaller amounts) for market development, IP protection, and commercialization activities. | Supports patent filing costs, market analysis, and buyer introductions for the portfolio. | acoa‑apeca.gc.ca – local ACOA office |
| **CIPO (Canadian Intellectual Property Office)** | Patent filing fees (small entity: $200–400 per application). Patent assignment and license recordal services. | Essential for securing priority dates before engaging in licensing or sale discussions. | ised.canada.ca/cipo – online filing |
| **Mitacs Accelerate** | Funds internships (50% cost‑share) connecting university researchers with industry to solve R&D challenges. | Can be used to engage graduate students to perform simulation or proof‑of‑concept work for lower‑TRL concepts (e.g., Fractal Metric Coil Design, Non‑Hermitian Heating). | mitacs.ca/accelerate – rolling |

---

## II. US Government Funding Programs

The US government is a major driver of advanced propulsion research, particularly through NASA, DARPA, and the Department of Defense. Non‑US entities can participate in many of these programs through teaming agreements with US partners.

| Program | Description | Relevance to Portfolio | Contact / Action |
|---------|-------------|------------------------|------------------|
| **NASA SBIR / STTR** | Phase I: up to $150 K for feasibility; Phase II: up to $750 K for prototype development; Phase III for commercialization. | All propulsion concepts qualify; NASA has specific topics for plasma, fusion, water‑based, and ABEP technologies. | sbir.nasa.gov – solicitations released annually |
| **DARPA Open BAAs** | Broad Agency Announcements for high‑risk, high‑payoff technologies. DARPA Otter specifically targets ABEP (Concept 5). | ABEP (5), Z3‑Phase‑Locked Thruster (11), Non‑Hermitian Heating (13) are directly aligned with current DARPA interests. | darpa.mil – search BAA‑HR0011 for relevant topics |
| **AFRL / SpaceWERX** | Small business innovation programs, often with streamlined application processes (e.g., Orbital Prime for space logistics). | Water‑based propulsion (6), dual‑use thermal management (17), and autonomous control (21–30) are strong fits. | spacewerx.us – open solicitations |
| **DOE ARPA‑E** | Advanced Research Projects Agency‑Energy funds breakthrough energy technologies, including fusion and advanced plasma systems. | Fusion‑related concepts (Holographic Plasma Confinement 1, Non‑Hermitian Heating 13, Information Pressure Regulator 20) are within scope. | arpa‑e.energy.gov – funding opportunities |
| **NSF (National Science Foundation)** | SBIR/STTR and core programs for fundamental research in AI, materials, and plasma physics. | Computational concepts (21–38) and materials concepts (39–48) are well‑matched. | nsf.gov – solicitations |

---

## III. International & Multilateral Funding

| Program | Description | Relevance | Contact / Action |
|---------|-------------|-----------|------------------|
| **ESA (European Space Agency) GSTP (General Support Technology Programme)** | Funds development of technologies for space applications; non‑ESA member states can participate through cooperation agreements. | Strong fit for all propulsion concepts; ESA has active programs in ABEP, water‑based propulsion, and electric propulsion. | esa.int – GSTP calls |
| **UK Space Agency International Bilateral Fund** | Supports collaborative projects between UK and international partners. | Potential for Canadian‑UK partnerships on water propulsion, AI control, and materials. | gov.uk – open calls |
| **Horizon Europe** | EU framework program for R&D; Canadian entities can participate in some clusters as associated partners. | Particularly relevant for advanced materials and AI components of the portfolio. | horizon‑europe.ec.europa.eu |

---

## IV. Private Investment & Corporate Partnerships

| Investor Type | Examples | Relevance | Approach |
|---------------|---------|-----------|----------|
| **Venture Capital (Space‑focused)** | Space Capital, Seraphim Space, DCVC, In-Q-Tel | All concepts with TRL ≥ 4; water‑based propulsion (6) and ABEP (5) are particularly attractive due to near‑term revenue potential. | Prepare pitch decks highlighting IP differentiation, market size, and team expertise. |
| **Corporate Venture Arms** | Lockheed Martin Ventures, Boeing HorizonX, Airbus Ventures | Strategic investment often precedes licensing or acquisition; target companies already active in space propulsion. | Engage through industry conferences (SmallSat, IAC) and technology scouting portals. |
| **Crowdfunding** | Kickstarter, Indiegogo (for hardware), Republic (for equity) | Suitable for small‑scale, high‑visibility concepts such as solar sail (10) or educational demonstrators of water‑based thrusters. | Build community engagement with simple prototypes. |
| **Prize Competitions** | NASA Centennial Challenges, XPRIZE (e.g., Next‑Gen Propulsion) | High‑visibility validation; can accelerate TRL and attract acquisition interest. | Monitor competition announcements; Concepts 5, 6, 10, 18 are strong candidates. |

---

## V. University & Technology Transfer Support

| Organization | Role | Relevance | Contact / Action |
|--------------|------|-----------|------------------|
| **Springboard Atlantic** | Atlantic Canada university technology transfer network; can assist with patent filing, market analysis, and buyer introductions. | All concepts; can provide non‑dilutive support to refine commercialization plans. | springboardatlantic.ca – free facilitation for researchers |
| **CIPO IP Assist** | Provides up to $1,000 in patent filing assistance for early‑stage inventions. | Reduces upfront patenting costs. | ised.canada.ca – IP Assist program |
| **NRC Industrial Research Assistance Program (IRAP) IP Assistance** | Up to $20 K for patent filing and IP strategy development. | Direct support for securing IP rights before licensing or sale. | irap.nrc.gc.ca – ask ITA for IP assistance |

---

## VI. Strategic Funding Recommendations by Concept Category

To maximize IP value, a phased funding strategy should be employed:

| Concept Category | Near‑Term Funding (TRL 2–4) | Medium‑Term Funding (TRL 4–6) | Commercialization (TRL 6–7) |
|------------------|----------------------------|-------------------------------|-----------------------------|
| **Propulsion Systems (e.g., Water‑Based Dual‑Mode, ABEP Fractal Intake)** | NRC‑IRAP, NBIF Proof of Concept, Mitacs | CSA STDP, NASA SBIR, DARPA BAA | Corporate venture, SBIR Phase III, Strategic acquisition |
| **Plasma/Fusion Control (e.g., Holographic Confinement, Non‑Hermitian Heating)** | DOE ARPA‑E, NSF, Mitacs | CSA STDP, NASA SBIR, AFRL | Strategic partnership with fusion startups (e.g., General Fusion, TAE) |
| **AI/Software (e.g., Self‑Writing Code, Coherence Controller)** | NRC‑IRAP, NBIF, Mitacs | NASA SBIR, NSF SBIR, DARPA | Licensing to prime contractors, acquisition by AI/defense companies |
| **Materials & Metrology (e.g., Bit‑Mass Material, Quantum Sensor)** | NRC‑IRAP, NBIF, Mitacs | NASA SBIR, NSF, CSA STDP | Licensing to aerospace materials suppliers, defense contractors |

---

## VII. Conclusion & Action Plan

The portfolio of 56 patent concepts is well‑positioned to leverage a wide range of non‑dilutive government grants, strategic corporate investments, and technology transfer support. A coordinated funding approach should:

1. **Establish IP priority** – File initial patent applications (using CIPO IP Assist and IRAP IP Assistance) to secure filing dates.
2. **Build TRL evidence** – Pursue NRC‑IRAP, NBIF, and Mitacs funding to demonstrate proof‑of‑concept for high‑value concepts.
3. **Validate in relevant environments** – Apply for CSA FAST (parabolic flights) and STDP (hardware development) for propulsion concepts; NASA SBIR for US market exposure.
4. **Engage strategic partners** – Present validated prototypes at industry conferences and through technology transfer networks (Springboard Atlantic) to identify licensing or acquisition candidates.

By following this roadmap, the IP holder can de‑risk the technology, increase valuation, and attract the right commercial partners—ultimately maximizing the return from this comprehensive portfolio.
