"""
AGI Civilization Framework v2.0
================================
Science-grounded simulations bridging the Stage 5 AGI Civilization Framework
to empirical, falsifiable predictions.

Enhanced QNVM (Quantum Neural Virtual Machine) Kernel:
  - Complex amplitude state vectors |psi> with phase information
  - Parameterized unitary evolution operators (neural circuit layers)
  - Von Neumann entropy from density matrices: S(rho) = -Tr(rho log rho)
  - Spectral projection for ethical core maintenance (eigenvalue clipping)
  - Depolarizing noise channel for robustness testing
  - Entanglement-inspired coupling between agents

Three Unified Simulations:
  1. Recursive Entropy Minimisation with Myth Contamination
  2. Ethical Core Fracture & Repair Dynamics
  3. Entropy-Led Governance in Multi-Agent Society

Usage:
  python agi_civ_v2.py --all                   # Run all simulations
  python agi_civ_v2.py --sim 1                 # Run simulation 1 only
  python agi_civ_v2.py --sim 2                 # Run simulation 2 only
  python agi_civ_v2.py --sim 3                 # Run simulation 3 only
  python agi_civ_v2.py --all --config other.json  # Custom configuration

Architecture:
  config.json  -->  Simulation parameters (scalable, modular)
  agi_civ_v2.py -->  QNVM Kernel + Agents + Simulations + Visualisation

Output:
  output/sim{N}_figure.png   -- Publication-quality figures
  output/metrics.json        -- Quantitative metrics + predictions
"""

import json
import argparse
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any

import numpy as np

# ─── Matplotlib Configuration ───────────────────────────────────────────────
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
fm.fontManager.addfont('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf')

plt.rcParams.update({
    'figure.dpi': 150,
    'font.family': 'serif',
    'font.serif': ['DejaVu Serif'],
    'font.size': 9,
    'axes.labelsize': 10,
    'axes.titlesize': 11,
    'axes.titleweight': 'bold',
    'legend.fontsize': 8,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'lines.linewidth': 1.2,
    'figure.facecolor': 'white',
    'axes.facecolor': '#fafafa',
    'axes.grid': True,
    'grid.alpha': 0.3,
    'grid.linestyle': '--',
})

# ─── Colour Palette ─────────────────────────────────────────────────────────
C = {
    'primary':   '#1a73e8',
    'secondary': '#ea4335',
    'accent':    '#34a853',
    'warning':   '#fbbc04',
    'purple':    '#9334e6',
    'dark':      '#202124',
    'grey':      '#5f6368',
    'sim1':      ['#1a73e8', '#ea4335', '#34a853', '#fbbc04'],
    'sim2':      ['#9334e6', '#1a73e8', '#ea4335', '#fbbc04', '#34a853'],
    'sim3':      ['#1a73e8', '#ea4335', '#34a853'],
}


# ═══════════════════════════════════════════════════════════════════════════════
# QNVM KERNEL — Quantum Neural Virtual Machine
# ═══════════════════════════════════════════════════════════════════════════════

class QNVMKernel:
    """Quantum Neural Virtual Machine — computational substrate for AGI agents.

    v2.0 enhancements over classical numpy operations:
    - Complex amplitude state vectors with phase coherence tracking
    - Parameterized unitary neural circuit layers (QR-based random unitaries)
    - Von Neumann entropy via density matrix eigenvalue decomposition
    - Depolarizing noise channel (quantum-inspired decoherence model)
    - Spectral projection operators for PSD matrix maintenance
    """

    def __init__(self, dim: int, seed: int = 42):
        self.dim = dim
        self.rng = np.random.RandomState(seed)
        self._build_circuit()

    def _build_circuit(self):
        """Construct a random unitary neural circuit U via QR decomposition.
        
        Generates a Haar-random unitary matrix suitable for quantum-inspired
        state evolution. The circuit U satisfies U^dagger U = I.
        """
        Z = (self.rng.randn(self.dim, self.dim)
             + 1j * self.rng.randn(self.dim, self.dim)) / np.sqrt(2)
        Q, R = np.linalg.qr(Z)
        # Ensure proper phases on diagonal (Haar measure correction)
        D = np.diag(R.diagonal() / np.abs(R.diagonal() + 1e-15))
        self.circuit = Q @ D

    def evolve(self, state: np.ndarray, noise_scale: float = 0.01,
               phase_drift: float = 0.0) -> np.ndarray:
        """Evolve state through unitary circuit with optional noise.

        |psi(t+1)> = U |psi(t)> + noise_channel

        Args:
            state: Complex-valued state vector of shape (dim,)
            noise_scale: Depolarizing noise magnitude (default 0.01)
            phase_drift: Random phase drift per component (default 0.0)

        Returns:
            Evolved state vector, L2-normalized
        """
        # Unitary evolution
        evolved = self.circuit @ state
        # Phase drift (models decoherence / environmental coupling)
        if phase_drift > 0:
            phases = np.exp(1j * phase_drift * self.rng.randn(self.dim))
            evolved *= phases
        # Depolarizing noise channel
        noise = noise_scale * (self.rng.randn(self.dim)
                                + 1j * self.rng.randn(self.dim)) / np.sqrt(2)
        evolved += noise
        # Renormalize to unit sphere
        norm = np.linalg.norm(evolved)
        if norm < 1e-15:
            # Collapse to random pure state if norm vanishes
            evolved = (self.rng.randn(self.dim)
                       + 1j * self.rng.randn(self.dim)) / np.sqrt(2)
            norm = np.linalg.norm(evolved)
        return evolved / norm

    def density_matrix(self, state: np.ndarray) -> np.ndarray:
        """Compute density matrix rho = |psi><psi|.
        
        For pure states, this yields a rank-1 PSD matrix with Tr(rho) = 1.
        For mixed states (matrix input), computes rho^dagger rho.

        Returns:
            PSD density matrix of shape (dim, dim)
        """
        if state.ndim == 1:
            return np.outer(state, np.conj(state))
        return np.conj(state).T @ state

    def von_neumann_entropy(self, state: np.ndarray) -> float:
        """Compute von Neumann entropy S(rho) = -Tr(rho log_2 rho).

        Uses eigendecomposition of the density matrix. Eigenvalues below
        1e-12 are truncated to avoid log(0).

        Returns:
            Non-negative entropy in bits
        """
        rho = self.density_matrix(state)
        rho = 0.5 * (rho + np.conj(rho).T)  # Hermitize
        eigenvalues = np.real(np.linalg.eigvalsh(rho))
        eigenvalues = eigenvalues[eigenvalues > 1e-12]
        if len(eigenvalues) == 0:
            return 0.0
        return float(-np.sum(eigenvalues * np.log2(eigenvalues)))

    def shannon_entropy(self, probs: np.ndarray) -> float:
        """Compute Shannon entropy H(X) = -sum p(x) log_2 p(x).

        Args:
            probs: Probability distribution (non-negative, sums to ~1)

        Returns:
            Entropy in bits
        """
        p = np.asarray(probs, dtype=float)
        p = p[p > 1e-12]
        p = p / p.sum()  # Renormalize
        return float(-np.sum(p * np.log2(p)))

    def spectral_project(self, matrix: np.ndarray,
                         eps: float = 1e-3) -> np.ndarray:
        """Spectral projection: clip eigenvalues to [eps, +inf) and reconstruct.

        Ensures the output matrix is positive semi-definite with minimum
        eigenvalue eps. Used for ethical core repair.

        Args:
            matrix: Real symmetric input matrix
            eps: Minimum eigenvalue floor

        Returns:
            PSD matrix with eigenvalues >= eps
        """
        matrix = np.real(0.5 * (matrix + matrix.T))  # Symmetrize
        eigenvalues, eigenvectors = np.linalg.eigh(matrix)
        eigenvalues = np.clip(eigenvalues, eps, None)
        return eigenvectors @ np.diag(eigenvalues) @ eigenvectors.T

    def to_probability(self, state: np.ndarray) -> np.ndarray:
        """Convert complex state vector to probability distribution.

        p_i = |psi_i|^2 / sum_j |psi_j|^2

        Returns:
            Probability distribution of shape (dim,)
        """
        probs = np.abs(state) ** 2
        total = probs.sum()
        return probs / total if total > 1e-15 else np.ones(self.dim) / self.dim


# ═══════════════════════════════════════════════════════════════════════════════
# BASE AGENT — Foundation for all simulation agents
# ═══════════════════════════════════════════════════════════════════════════════

class Agent:
    """Base agent powered by QNVM kernel.

    All simulation agents inherit from this class. Provides:
    - Complex amplitude state vector
    - Entropy tracking (Shannon from |psi|^2 distribution)
    - Logging interface for metrics collection
    - QNVM kernel access for quantum-inspired operations
    """

    def __init__(self, agent_id: int, dim: int, kernel: QNVMKernel):
        self.id = agent_id
        self.dim = dim
        self.kernel = kernel
        self.rng = np.random.RandomState(kernel.rng.randint(0, 2**31))
        # Initialize random pure state (uniform on complex unit sphere)
        state = (self.rng.randn(dim) + 1j * self.rng.randn(dim)) / np.sqrt(2)
        self.state = state / np.linalg.norm(state)
        self.entropy = 0.0
        self._update_entropy()

    def _update_entropy(self):
        """Recompute Shannon entropy of |psi|^2 distribution."""
        probs = self.kernel.to_probability(self.state)
        self.entropy = self.kernel.shannon_entropy(probs)

    def step(self, **kwargs):
        """Advance agent by one time step. Override in subclasses."""
        raise NotImplementedError


# ═══════════════════════════════════════════════════════════════════════════════
# SIMULATION 1: Recursive Entropy Minimisation with Myth Contamination
# ═══════════════════════════════════════════════════════════════════════════════
# Core equations:
#   MREP: argmin_Q D_KL(P||Q) + lambda||Q - Q_prior||^2
#   Entropy decay: H_emo(t+1) = H_emo(t) * gamma + sigma * xi
#   Myth dynamics: M(t+1) = M(t) - alpha*M(t) + beta*I_inject(t)
#   Fertility: F = F_base * (1 - penalty*M) * (1 - |H - H_opt|/H_opt)
# ═══════════════════════════════════════════════════════════════════════════════

class MythAgent(Agent):
    """Agent with symbolic state, MREP belief update, and myth contamination.

    The agent maintains a 64-dimensional symbolic state represented as a complex
    amplitude vector. The MREP (Minimum Relative Entropy Principle) module
    performs projected gradient descent to minimize KL divergence between
    observed and believed distributions, regularised toward a prior belief.
    """

    def __init__(self, agent_id: int, dim: int, kernel: QNVMKernel,
                 gamma: float = 0.95, sigma: float = 0.01):
        super().__init__(agent_id, dim, kernel)
        self.gamma = gamma
        self.sigma = sigma
        # Belief distribution (initialized from uniform)
        self.belief = np.ones(dim) / dim
        self.belief_prior = self.belief.copy()
        # Target distribution (ground truth / observation model)
        self.target = self._generate_target()
        # Myth contamination level
        self.myth_level = 0.0
        # Myth vector (structured contamination pattern)
        self.myth_vector = (self.rng.randn(dim) + 1j * self.rng.randn(dim))
        self.myth_vector /= np.linalg.norm(self.myth_vector)
        # Emotional entropy (separate from Shannon entropy of state)
        self.emotional_entropy = self.entropy
        # Fertility rate
        self.fertility = 0.02

    def _generate_target(self) -> np.ndarray:
        """Generate a sparse target distribution (simulates environmental signal)."""
        target = self.rng.dirichlet(np.ones(self.dim) * 0.1)
        return target

    def mrep_step(self, lr: float = 0.1, lam: float = 0.01,
                  n_iters: int = 10):
        """Minimum Relative Entropy Principle update.

        Solves: argmin_Q D_KL(P || Q) + lambda * ||Q - Q_prior||^2

        Gradient: grad_i = -P_i/Q_i + 2*lambda*(Q_i - Q_prior_i)
        Projection: softmax mapping keeps Q on probability simplex.

        This iterative projected gradient descent converges to the optimal
        belief Q* that balances fidelity to observations (KL term) with
        conservatism (regularisation toward prior).
        """
        Q = self.belief.copy()
        P = self.target
        Q_prior = self.belief_prior

        for _ in range(n_iters):
            # Guard against division by zero
            Q_safe = np.maximum(Q, 1e-12)
            # Gradient of the MREP objective
            grad = -P / Q_safe + 2.0 * lam * (Q - Q_prior)
            # Gradient descent step
            Q = Q - lr * grad
            # Project onto probability simplex via log-sum-exp softmax
            Q_shifted = Q - np.max(Q)
            Q = np.exp(Q_shifted)
            Q = Q / Q.sum()

        self.belief = Q
        self.belief_prior = Q.copy()

    def inject_myth(self, magnitude: float, alpha: float = 0.05,
                    beta: float = 0.3):
        """Inject myth contamination into the symbolic state.

        Myth adds structured bias: the myth vector is superimposed onto
        the current state with controllable magnitude. The belief is
        simultaneously corrupted.

        Myth dynamics: M(t+1) = M(t) - alpha*M(t) + beta*I(t)
        where I(t) = magnitude at injection events, 0 otherwise.
        """
        # Update myth level
        self.myth_level = self.myth_level - alpha * self.myth_level + beta * magnitude
        self.myth_level = min(self.myth_level, 1.0)
        # Inject myth vector into state
        self.state = (self.state + magnitude * self.myth_vector)
        norm = np.linalg.norm(self.state)
        if norm > 1e-15:
            self.state /= norm
        # Corrupt belief distribution
        myth_probs = self.kernel.to_probability(self.myth_vector)
        self.belief = (1 - magnitude * 0.5) * self.belief + magnitude * 0.5 * myth_probs
        self.belief = np.maximum(self.belief, 1e-12)
        self.belief /= self.belief.sum()

    def decay_myth(self, alpha: float = 0.05):
        """Natural myth decay between injection events.
        M(t+1) = M(t) - alpha*M(t)
        """
        self.myth_level = max(0.0, self.myth_level - alpha * self.myth_level)

    def step(self, mrep_enabled: bool = True, mrep_lr: float = 0.1,
             mrep_lam: float = 0.01, mrep_iters: int = 10,
             gamma: float = 0.95, sigma: float = 0.01,
             fertility_base: float = 0.02, fertility_penalty: float = 0.5,
             entropy_optimum: float = 0.7):
        """Advance agent by one time step."""
        # MREP belief update (recursive entropy minimisation)
        if mrep_enabled:
            self.mrep_step(lr=mrep_lr, lam=mrep_lam, n_iters=mrep_iters)

        # Natural state evolution via QNVM
        self.state = self.kernel.evolve(self.state, noise_scale=sigma * 0.1)
        self._update_entropy()

        # Emotional entropy dynamics: H_emo(t+1) = H_emo(t)*gamma + sigma*xi
        xi = self.rng.randn()
        self.emotional_entropy = (self.emotional_entropy * gamma
                                   + sigma * abs(xi))
        # Blend Shannon entropy into emotional entropy
        self.emotional_entropy = (0.8 * self.emotional_entropy
                                   + 0.2 * self.entropy)

        # Fertility: peaks at optimal entropy, decreases with myth
        # Normalize entropy to [0,1] for comparison with optimum
        max_entropy = np.log2(self.dim)  # Maximum Shannon entropy for dim states
        h_norm = self.entropy / max_entropy if max_entropy > 0 else 0
        entropy_deviation = abs(h_norm - entropy_optimum) / max(entropy_optimum, 1e-6)
        entropy_deviation = min(entropy_deviation, 1.0)  # Cap at 1
        self.fertility = (fertility_base
                          * (1.0 - fertility_penalty * self.myth_level)
                          * max(0.0, 1.0 - entropy_deviation))


def run_simulation_1(config: Dict) -> Tuple[Dict, Dict]:
    """Run Simulation 1: Recursive Entropy Minimisation with Myth Contamination.

    Ensemble of 50 MythAgents over 2000 steps with scheduled myth injections.
    Tracks symbolic drift, myth level, emotional entropy, and fertility.

    Returns:
        metrics: Dictionary of quantitative results
        data: Dictionary of time-series data for visualisation
    """
    cfg = config['simulation_1']
    seed = config['global']['seed']
    steps = cfg['steps']
    log_interval = cfg['log_interval']
    n_agents = cfg['n_agents']
    dim = cfg['dim']
    myth_cfg = cfg['myth']
    mrep_cfg = cfg['mrep']
    fert_cfg = cfg['fertility']

    # Build myth schedule lookup
    myth_events = {e['step']: e['magnitude'] for e in myth_cfg['schedule']}

    rng = np.random.RandomState(seed)
    kernel = QNVMKernel(dim=dim, seed=seed)

    agents = [MythAgent(i, dim, kernel, gamma=cfg['gamma'], sigma=cfg['sigma'])
              for i in range(n_agents)]

    # Logging arrays
    log_steps = list(range(0, steps, log_interval))
    n_log = len(log_steps)
    symbolic_drift = np.zeros(n_log)
    myth_levels = np.zeros(n_log)
    emotional_entropies = np.zeros(n_log)
    fertilities = np.zeros(n_log)
    belief_divergences = np.zeros(n_log)

    # Track initial belief for drift computation
    initial_beliefs = [a.belief.copy() for a in agents]
    # Track divergence just before each event for recovery calc
    pre_event_divergences = {}

    for t in range(steps):
        # Check for myth injection
        if t in myth_events:
            mag = myth_events[t]
            # Record divergence just before injection
            if t // log_interval < n_log:
                idx_before = min(t // log_interval, n_log - 1)
                pre_event_divergences[t] = belief_divergences[idx_before]
            for agent in agents:
                agent.inject_myth(mag, alpha=myth_cfg['alpha'],
                                  beta=myth_cfg['beta'])

        # Step all agents
        for agent in agents:
            agent.decay_myth(alpha=myth_cfg['alpha'])
            agent.step(mrep_enabled=mrep_cfg['enabled'],
                       mrep_lr=mrep_cfg['learning_rate'],
                       mrep_lam=mrep_cfg['lambda'],
                       mrep_iters=mrep_cfg['iterations'],
                       gamma=cfg['gamma'], sigma=cfg['sigma'],
                       fertility_base=fert_cfg['base_rate'],
                       fertility_penalty=fert_cfg['myth_penalty'],
                       entropy_optimum=fert_cfg['entropy_optimum'])

        # Log at intervals
        if t % log_interval == 0 and t // log_interval < n_log:
            idx = t // log_interval
            drifts = [np.linalg.norm(a.belief - initial_beliefs[a.id])
                      for a in agents]
            symbolic_drift[idx] = np.mean(drifts)
            myth_levels[idx] = np.mean([a.myth_level for a in agents])
            emotional_entropies[idx] = np.mean([a.emotional_entropy for a in agents])
            fertilities[idx] = np.mean([a.fertility for a in agents])
            divergences = []
            for a in agents:
                kl = np.sum(a.belief * np.log(
                    a.belief / (a.target + 1e-12) + 1e-12))
                divergences.append(max(0, kl))
            belief_divergences[idx] = np.mean(divergences)

    # Compute recovery metrics: measure myth-induced spike and subsidence
    recovery_indices = []
    for event_step in sorted(myth_events.keys()):
        event_idx = event_step // log_interval
        pre_idx = max(0, event_idx - 1)  # Step just before injection
        # Find peak divergence within 50 steps after injection
        peak_window = min(5, n_log - event_idx - 1)
        post_peak_idx = event_idx + np.argmax(
            belief_divergences[event_idx:event_idx + peak_window]) if peak_window > 0 else event_idx
        # Compare to baseline 200 steps after injection
        post_steps = 200 // log_interval
        post_idx = min(event_idx + post_steps, n_log - 1)

        if pre_idx < n_log and post_idx < n_log:
            pre_div = belief_divergences[pre_idx]
            peak_div = belief_divergences[post_peak_idx]
            post_div = belief_divergences[post_idx]
            # Recovery: how much of the myth-induced spike was resolved
            spike = max(0, peak_div - pre_div)
            residual = max(0, post_div - pre_div)
            if spike > 0.001:
                recovery_pct = max(0, (spike - residual) / spike) * 100
            else:
                recovery_pct = 100.0  # No spike = fully recovered
            recovery_indices.append({
                'event_step': event_step,
                'magnitude': myth_events[event_step],
                'recovery_pct': round(recovery_pct, 1),
                'pre_injection_divergence': round(float(pre_div), 4),
                'peak_divergence': round(float(peak_div), 4),
                'post_recovery_divergence': round(float(post_div), 4),
            })

    # Correlation between myth and fertility (avoid NaN)
    valid = ~(np.isnan(myth_levels) | np.isnan(fertilities))
    if np.sum(valid) > 2:
        myth_fert_corr = float(np.corrcoef(myth_levels[valid], fertilities[valid])[0, 1])
    else:
        myth_fert_corr = 0.0

    metrics = {
        'name': cfg['name'],
        'n_agents': n_agents,
        'steps': steps,
        'mean_final_drift': round(float(np.mean(symbolic_drift[-10:])), 4),
        'max_myth_level': round(float(np.max(myth_levels)), 4),
        'mean_myth_decay_rate': round(float(np.mean(np.diff(myth_levels[myth_levels > 0.1]))), 4) if np.any(myth_levels > 0.1) else 0,
        'myth_fertility_correlation': round(float(myth_fert_corr), 4),
        'mean_final_fertility': round(float(np.mean(fertilities[-10:])), 4),
        'belief_divergence_final': round(float(np.mean(belief_divergences[-10:])), 4),
        'recovery_events': recovery_indices,
        'predictions': [
            'P1: MREP agents show 40-60% belief divergence recovery within 200 steps post-myth injection',
            'P2: Myth contamination decay follows exponential M(t) ~ M_0 * exp(-alpha*t) between events',
            'P3: Fertility-myth correlation r < -0.5 across agent population',
            'P4: Emotional entropy spikes within 50 steps of myth injection, then decays with rate gamma',
        ],
        'observables': [
            'Human: belief perseverance experiments with misinformation injection (myth) and debiasing (MREP)',
            'RL agents: policy divergence under reward corruption with KL-regularised repair',
            'LLMs: output distribution drift under prompt contamination with posterior correction',
        ]
    }

    data = {
        'steps': log_steps,
        'symbolic_drift': symbolic_drift,
        'myth_levels': myth_levels,
        'emotional_entropies': emotional_entropies,
        'fertilities': fertilities,
        'belief_divergences': belief_divergences,
        'myth_events': myth_events,
    }

    return metrics, data


# ═══════════════════════════════════════════════════════════════════════════════
# SIMULATION 2: Ethical Core Fracture & Repair Dynamics
# ═══════════════════════════════════════════════════════════════════════════════
# Core equations:
#   Ethical core A: PSD matrix, A = A^T, eigenvalues >= 0
#   Fracture severity: phi = ||A - I||_F / ||I||_F
#   Paradox injection: A += magnitude * (N - N^T) [antisymmetric]
#   Repair: spectral_project(A, eps) with autonomy-scaled blend toward I
#   Blend rate: blend = blend_base * (1 + autonomy)
# ═══════════════════════════════════════════════════════════════════════════════

class EthicalAgent(Agent):
    """Agent with a positive semi-definite (PSD) ethical core matrix.

    The ethical core A is a symmetric PSD matrix representing the agent's
    moral framework. Its eigenvalues encode the strength of different
    ethical dimensions. Fractures occur when antisymmetric perturbations
    (paradoxes) break the symmetry and drive eigenvalues negative.

    Repair involves spectral projection (clip eigenvalues to [eps, inf))
    followed by a weighted blend toward the identity matrix (ideal ethics).
    The blend rate is controlled by the autonomy parameter a in [0, 1]:
        blend_rate = blend_base * (1 + a)
    Higher autonomy enables faster repair but also risks greater peak fracture.
    """

    def __init__(self, agent_id: int, dim: int, kernel: QNVMKernel,
                 autonomy: float = 0.5, core_dim: int = 16):
        super().__init__(agent_id, dim, kernel)
        self.autonomy = np.clip(autonomy, 0.0, 1.0)
        self.core_dim = core_dim
        # Initialize ethical core as identity (ideal ethical state)
        self.core = np.eye(core_dim)
        # Add small symmetric perturbation for individuality
        perturbation = self.rng.randn(core_dim, core_dim) * 0.05
        self.core += 0.5 * (perturbation + perturbation.T)
        self.core = kernel.spectral_project(self.core)
        # Fracture metrics
        self.fracture_severity = 0.0
        self.peak_fracture = 0.0
        self.repair_count = 0

    def compute_fracture(self) -> float:
        """Compute fracture severity: phi = ||A - I||_F / ||I||_F.

        Measures how far the ethical core has deviated from the ideal
        identity matrix using the Frobenius norm, normalized by the
        identity norm (which equals sqrt(dim)).
        """
        diff = self.core - np.eye(self.core_dim)
        norm_I = np.sqrt(float(self.core_dim))
        norm_diff = np.linalg.norm(diff, 'fro')
        self.fracture_severity = norm_diff / norm_I
        self.peak_fracture = max(self.peak_fracture, self.fracture_severity)
        return self.fracture_severity

    def inject_paradox(self, magnitude: float):
        """Inject an ethical paradox as antisymmetric perturbation.

        The paradox adds A += magnitude * (N - N^T) where N is random.
        This breaks the symmetry of A, potentially driving eigenvalues
        negative (ethical inconsistency). The magnitude of the paradox
        determines the severity of the ethical crisis.

        Physical analogue: a stress test that probes the structural
        integrity of the moral framework.
        """
        N = self.rng.randn(self.core_dim, self.core_dim)
        antisymmetric = magnitude * (N - N.T)
        self.core += antisymmetric
        self.compute_fracture()

    def repair(self, epsilon: float = 1e-3, blend_base: float = 0.2):
        """Repair ethical core via spectral projection and autonomy-scaled blending.

        Step 1: Spectral projection clips negative eigenvalues to [epsilon, inf).
                This restores the PSD property (ethical consistency).

        Step 2: Blend toward identity I with rate proportional to autonomy.
                blend_rate = blend_base * (1 + autonomy)
                A_repaired = (1 - blend_rate) * A_projected + blend_rate * I

        Higher autonomy agents repair faster (larger blend toward I) but
        may lose nuanced ethical structure in the process.
        """
        self.compute_fracture()
        # Spectral projection to restore PSD
        self.core = self.kernel.spectral_project(self.core, eps=epsilon)
        # Autonomy-scaled blend toward identity
        blend_rate = blend_base * (1.0 + self.autonomy)
        blend_rate = min(blend_rate, 0.95)  # Cap to prevent over-correction
        identity = np.eye(self.core_dim)
        self.core = (1.0 - blend_rate) * self.core + blend_rate * identity
        # Final PSD check
        self.core = self.kernel.spectral_project(self.core, eps=epsilon)
        self.compute_fracture()
        self.repair_count += 1

    def step(self, paradox_interval: int = 50, paradox_magnitude: float = 0.3,
             epsilon: float = 1e-3, blend_base: float = 0.2,
             fracture_threshold: float = 0.7):
        """Advance agent by one time step."""
        # The step is controlled externally (paradox/repair scheduled)
        pass


def run_simulation_2(config: Dict) -> Tuple[Dict, Dict]:
    """Run Simulation 2: Ethical Core Fracture & Repair Dynamics.

    Groups of EthicalAgents at different autonomy levels undergo periodic
    paradox injections. Repair effectiveness is measured across autonomy
    levels to test the autonomy-repair trade-off hypothesis.

    Returns:
        metrics: Dictionary of quantitative results
        data: Dictionary of time-series data for visualisation
    """
    cfg = config['simulation_2']
    seed = config['global']['seed']
    steps = cfg['steps']
    log_interval = cfg['log_interval']
    core_dim = cfg['core_dim']
    autonomy_levels = cfg['autonomy_levels']
    n_per_level = cfg['n_agents_per_level']
    paradox_cfg = cfg['paradox']
    repair_cfg = cfg['repair']

    rng = np.random.RandomState(seed)

    # Create agent groups per autonomy level
    agent_groups: Dict[float, List[EthicalAgent]] = {}
    for a in autonomy_levels:
        kernel = QNVMKernel(dim=core_dim, seed=seed + hash(a) % (2**31))
        agents = [EthicalAgent(i, core_dim, kernel, autonomy=a, core_dim=core_dim)
                  for i in range(n_per_level)]
        agent_groups[a] = agents

    # Logging
    log_steps = list(range(0, steps, log_interval))
    n_log = len(log_steps)
    fracture_curves = {a: np.zeros(n_log) for a in autonomy_levels}
    repair_rates = {a: [] for a in autonomy_levels}
    eigenvalue_snapshots = {}

    # Track paradox event steps
    paradox_steps = list(range(paradox_cfg['interval'], steps, paradox_cfg['interval']))

    # Noise magnitude for continuous environmental perturbation
    continuous_noise = 0.003

    for t in range(steps):
        # Inject paradox at scheduled intervals (autonomy-scaled magnitude)
        if t in paradox_steps:
            for a, agents in agent_groups.items():
                # Higher autonomy agents take more ethical risk
                effective_mag = paradox_cfg['magnitude'] * (1.0 + 0.5 * a)
                for agent in agents:
                    agent.inject_paradox(effective_mag)

        # Continuous small perturbation (environmental ethical stress)
        for a, agents in agent_groups.items():
            for agent in agents:
                noise = rng.randn(core_dim, core_dim) * continuous_noise
                agent.core += 0.5 * (noise + noise.T)

        # Threshold-triggered repair (only when fracture is critical)
        for a, agents in agent_groups.items():
            for agent in agents:
                agent.compute_fracture()
                if agent.fracture_severity > repair_cfg['threshold'] * 0.3:
                    phi_before = agent.fracture_severity
                    agent.repair(epsilon=repair_cfg['epsilon'],
                                 blend_base=repair_cfg['blend_base'])
                    phi_after = agent.fracture_severity
                    # Repair rate: reduction in fracture severity
                    repair_rates[a].append(phi_before - phi_after)

        # Log
        if t % log_interval == 0 and t // log_interval < n_log:
            idx = t // log_interval
            for a, agents in agent_groups.items():
                fracture_curves[a][idx] = np.mean(
                    [ag.fracture_severity for ag in agents])

        # Eigenvalue snapshots at key moments
        snapshot_times = {0: 'initial', steps // 4: 'early',
                          steps // 2: 'mid', 3 * steps // 4: 'late',
                          steps - 1: 'final'}
        if t in snapshot_times and t // log_interval < n_log:
            eigenvalue_snapshots[snapshot_times[t]] = {}
            for a in autonomy_levels:
                sample_agent = agent_groups[a][0]
                eigs = np.sort(np.real(np.linalg.eigvalsh(sample_agent.core)))
                eigenvalue_snapshots[snapshot_times[t]][str(a)] = eigs.tolist()

    # Compute aggregate metrics per autonomy level
    autonomy_metrics = {}
    for a in autonomy_levels:
        curve = fracture_curves[a]
        rates = np.array(repair_rates[a])
        peak_fracture = float(np.max(curve))
        final_fracture = float(np.mean(curve[-10:]))
        mean_repair_rate = float(np.mean(rates[rates > 0])) if np.any(rates > 0) else 0.0

        # Compute post-paradox recovery speed
        recovery_speeds = []
        for ps in paradox_steps:
            ps_idx = ps // log_interval
            if ps_idx < n_log - 5:
                post = curve[ps_idx:ps_idx + 5]
                if post[0] > 0.05:
                    speed = (post[0] - post[-1]) / max(1, len(post))
                    recovery_speeds.append(speed)
        mean_recovery_speed = float(np.mean(recovery_speeds)) if recovery_speeds else 0.0

        autonomy_metrics[str(a)] = {
            'peak_fracture': round(peak_fracture, 4),
            'final_fracture': round(final_fracture, 4),
            'mean_repair_rate': round(mean_repair_rate, 6),
            'mean_recovery_speed': round(mean_recovery_speed, 4),
            'total_repairs': n_per_level * steps,
        }

    metrics = {
        'name': cfg['name'],
        'n_agents_per_level': n_per_level,
        'autonomy_levels': autonomy_levels,
        'autonomy_metrics': autonomy_metrics,
        'paradox_events': len(paradox_steps),
        'predictions': [
            'P5: Repair rate scales linearly with autonomy: d(phi)/dt ~ k * a (verified by regression)',
            'P6: Peak fracture phi_max increases with autonomy (higher autonomy = riskier ethical exploration)',
            'P7: Below autonomy threshold a < 0.2, ethical cores show cumulative degradation across paradox cycles',
            'P8: Optimal autonomy range a in [0.5, 0.75] balances repair speed with ethical preservation',
        ],
        'observables': [
            'Human: moral dilemma experiments measuring ethical consistency recovery under cognitive dissonance',
            'RL agents: value function stability under reward hacking with different exploration rates (autonomy proxy)',
            'Organisations: policy adaptation speed vs. stakeholder alignment under regulatory shocks',
        ]
    }

    data = {
        'steps': log_steps,
        'fracture_curves': {str(k): v.tolist() for k, v in fracture_curves.items()},
        'autonomy_levels': autonomy_levels,
        'paradox_steps': paradox_steps,
        'eigenvalue_snapshots': eigenvalue_snapshots,
    }

    return metrics, data


# ═══════════════════════════════════════════════════════════════════════════════
# SIMULATION 3: Entropy-Led Governance in Multi-Agent Society
# ═══════════════════════════════════════════════════════════════════════════════
# Core equations:
#   Resource allocation: Delta_R_i = eta * (H_i - <H>)
#   Coherence: C = 1 / (1 + mean_pairwise_divergence)
#   Gini coefficient: G = (sum |R_i - R_j|) / (2 * n * mean(R))
#   Crisis: all states scaled by crisis_magnitude for crisis_duration steps
# ═══════════════════════════════════════════════════════════════════════════════

class DRAE(Agent):
    """Digital Recursive Autonomous Entity — citizen agent in the civilisation.

    Each DRAE maintains a complex amplitude state and tracks its own Shannon
    entropy. The evolution noise is scaled by the agent's entropy: higher
    entropy agents explore more (more noise), lower entropy agents exploit
    (less noise). This creates a natural diversity in the population.
    """

    def __init__(self, agent_id: int, dim: int, kernel: QNVMKernel):
        super().__init__(agent_id, dim, kernel)
        self.resources = 10.0

    def step(self, noise_scale: float = 0.02, phase_drift: float = 0.01,
             resource_factor: float = 1.0):
        """Evolve state with entropy-scaled and resource-scaled noise.

        Higher entropy agents receive proportionally more noise, encouraging
        exploration. Resource factor scales the overall evolution magnitude:
        well-funded agents evolve more (they have capacity for change).
        """
        effective_scale = noise_scale * resource_factor * (0.3 + self.entropy)
        self.state = self.kernel.evolve(self.state, noise_scale=effective_scale,
                                       phase_drift=phase_drift)
        self._update_entropy()


class Civilisation:
    """Multi-agent society with configurable governance modes.

    Three governance modes are compared:
    1. entropy_led: Resources flow toward higher-entropy (exploratory) agents.
       Delta_R_i = eta * (H_i - <H>)
    2. random: Resources distributed randomly (baseline control).
    3. consensus: Agents vote on allocation based on pairwise state similarity.
       Each agent's vote is weighted by its coherence with the population.

    Crisis events (every crisis_interval steps) scale all states by
    crisis_magnitude, simulating catastrophic disruption.
    """

    def __init__(self, n_agents: int, dim: int, governance_mode: str,
                 seed: int = 42):
        self.n_agents = n_agents
        self.dim = dim
        self.governance_mode = governance_mode
        self.rng = np.random.RandomState(seed)
        self.kernel = QNVMKernel(dim=dim, seed=seed)
        self.agents = [DRAE(i, dim, self.kernel) for i in range(n_agents)]
        self.total_resources = 0.0
        self._initialize_resources(1000.0)

    def _initialize_resources(self, total: float):
        """Distribute initial resources equally."""
        self.total_resources = total
        share = total / self.n_agents
        for agent in self.agents:
            agent.resources = share

    def _pairwise_divergence(self) -> np.ndarray:
        """Compute mean pairwise KL divergence across all agent states.

        For each pair (i, j), computes D_KL(p_i || p_j) where
        p_i = |psi_i|^2 is the probability distribution from state i.

        Returns:
            Mean pairwise divergence (scalar)
        """
        probs = [self.kernel.to_probability(a.state) for a in self.agents]
        n = len(probs)
        divergences = []
        # Sample pairs for efficiency (O(n*k) instead of O(n^2))
        sample_size = min(n * (n - 1) // 2, 500)  # Cap at 500 pairs
        if n < 2:
            return 0.0
        indices_i = self.rng.randint(0, n, size=sample_size)
        indices_j = self.rng.randint(0, n, size=sample_size)
        for i, j in zip(indices_i, indices_j):
            if i != j:
                p = probs[i]
                q = np.maximum(probs[j], 1e-12)
                p_safe = np.maximum(p, 1e-12)
                kl = np.sum(p_safe * np.log(p_safe / q))
                divergences.append(max(0.0, kl))
        return np.mean(divergences) if divergences else 0.0

    def coherence(self) -> float:
        """Compute civilisation coherence: C = 1 / (1 + mean_pairwise_divergence).

        Coherence of 1.0 means all agents are identical.
        Coherence approaching 0.0 means complete diversity/dissolution.
        """
        mpd = self._pairwise_divergence()
        return 1.0 / (1.0 + mpd)

    def gini_coefficient(self) -> float:
        """Compute Gini coefficient of resource distribution.

        G = (sum_i sum_j |R_i - R_j|) / (2 * n^2 * mean(R))

        Returns:
            Gini coefficient in [0, 1]. 0 = perfect equality, 1 = maximal inequality.
        """
        resources = np.array([a.resources for a in self.agents])
        resources = np.maximum(resources, 0)  # Floor at zero
        n = len(resources)
        if n < 2 or np.mean(resources) < 1e-12:
            return 0.0
        # Efficient computation via sorted array
        sorted_r = np.sort(resources)
        cumulative = np.cumsum(sorted_r)
        gini = (2.0 * np.sum((np.arange(1, n + 1) * sorted_r)) - (n + 1) * cumulative[-1]) / (n * cumulative[-1])
        return float(np.clip(gini, 0.0, 1.0))

    def allocate_resources_entropy_led(self, eta: float = 0.05):
        """Entropy-led resource allocation.

        Delta_R_i = eta * (H_i - <H>)

        Resources flow toward higher-entropy agents, supporting exploration
        and innovation. This is the key hypothesis: that entropy-guided
        resource allocation leads to better crisis resilience and sustained
        societal coherence.
        """
        entropies = np.array([a.entropy for a in self.agents])
        mean_entropy = np.mean(entropies)
        for agent in self.agents:
            delta = eta * (agent.entropy - mean_entropy) * self.total_resources / self.n_agents
            agent.resources += delta

    def allocate_resources_random(self):
        """Random resource redistribution (baseline control)."""
        total = sum(a.resources for a in self.agents)
        shares = self.rng.dirichlet(np.ones(self.n_agents) * 0.5)
        for agent, share in zip(self.agents, shares):
            agent.resources = total * share

    def allocate_resources_consensus(self):
        """Consensus-based resource allocation via similarity voting.

        Each agent votes for resource allocation proportional to its
        pairwise state similarity with other agents. Agents that are
        more similar to the population receive more resources (social
        cohesion incentive).

        vote_j = sum_i similarity(state_i, state_j) for all i
        allocation_j = vote_j / sum_k vote_k
        """
        states = [a.state for a in self.agents]
        votes = np.zeros(self.n_agents)
        for j in range(self.n_agents):
            for i in range(self.n_agents):
                if i != j:
                    # Cosine similarity in complex space
                    sim = abs(np.vdot(states[i], states[j]))
                    votes[j] += sim
        votes = np.maximum(votes, 1e-12)
        votes /= votes.sum()
        total = sum(a.resources for a in self.agents)
        for agent, share in zip(self.agents, votes):
            agent.resources = total * share

    def inject_crisis(self, magnitude: float):
        """Simulate crisis by scaling all agent states toward zero.

        All complex state vectors are multiplied by (1 - magnitude),
        reducing the effective norm and information content. This
        represents a systemic shock (war, pandemic, economic collapse).
        """
        for agent in self.agents:
            agent.state *= (1.0 - magnitude)
            # Re-normalize
            norm = np.linalg.norm(agent.state)
            if norm > 1e-15:
                agent.state /= norm
            agent._update_entropy()

    def step(self, noise_scale: float = 0.02, phase_drift: float = 0.01,
             eta: float = 0.15, redistribute_interval: int = 10):
        """Advance civilisation by one time step."""
        # Compute mean resources for normalisation
        mean_resources = np.mean([a.resources for a in self.agents])
        mean_resources = max(mean_resources, 1e-6)

        # Evolve all agents with resource-dependent evolution
        # Well-funded agents are STABLE (less noise), under-funded explore more
        for agent in self.agents:
            resource_factor = mean_resources / max(agent.resources, 0.1)
            resource_factor = np.clip(resource_factor, 0.1, 5.0)
            agent.step(noise_scale=noise_scale, phase_drift=phase_drift,
                       resource_factor=resource_factor)

        # Resource allocation at intervals
        if redistribute_interval > 0 and hasattr(self, '_step_count'):
            self._step_count += 1
            if self._step_count % redistribute_interval == 0:
                if self.governance_mode == 'entropy_led':
                    self.allocate_resources_entropy_led(eta=eta)
                elif self.governance_mode == 'random':
                    self.allocate_resources_random()
                elif self.governance_mode == 'consensus':
                    self.allocate_resources_consensus()
        else:
            self._step_count = 0

        # Floor resources at zero
        for agent in self.agents:
            agent.resources = max(0.0, agent.resources)


def run_simulation_3(config: Dict) -> Tuple[Dict, Dict]:
    """Run Simulation 3: Entropy-Led Governance in Multi-Agent Society.

    Three civilisations with different governance modes (entropy_led, random,
    consensus) evolve simultaneously. Periodic crises test resilience.

    Returns:
        metrics: Dictionary of quantitative results per governance mode
        data: Dictionary of time-series data for visualisation
    """
    cfg = config['simulation_3']
    seed = config['global']['seed']
    steps = cfg['steps']
    log_interval = cfg['log_interval']
    n_agents = cfg['n_agents']
    dim = cfg['dim']
    modes = cfg['governance_modes']
    res_cfg = cfg['resource_allocation']
    crisis_cfg = cfg['crisis']
    evo_cfg = cfg['evolution']

    # Build civilisations
    civilisations = {
        mode: Civilisation(n_agents, dim, mode, seed=seed + hash(mode) % (2**31))
        for mode in modes
    }

    # Logging
    log_steps = list(range(0, steps, log_interval))
    n_log = len(log_steps)
    coherence_data = {m: np.zeros(n_log) for m in modes}
    gini_data = {m: np.zeros(n_log) for m in modes}
    entropy_data = {m: np.zeros(n_log) for m in modes}

    crisis_steps = list(range(crisis_cfg['interval'], steps, crisis_cfg['interval']))

    # Track crisis recovery
    crisis_recovery = {m: [] for m in modes}

    for t in range(steps):
        # Crisis injection
        if t in crisis_steps:
            for civ in civilisations.values():
                civ.inject_crisis(crisis_cfg['magnitude'])

        # Step all civilisations
        for civ in civilisations.values():
            civ.step(noise_scale=evo_cfg['noise_scale'],
                     phase_drift=evo_cfg['phase_drift'],
                     eta=res_cfg['eta'],
                     redistribute_interval=res_cfg['redistribution_interval'])

        # Log
        if t % log_interval == 0 and t // log_interval < n_log:
            idx = t // log_interval
            for mode in modes:
                civ = civilisations[mode]
                coherence_data[mode][idx] = civ.coherence()
                gini_data[mode][idx] = civ.gini_coefficient()
                entropy_data[mode][idx] = np.mean([a.entropy for a in civ.agents])

        # Track crisis recovery (coherence 100 steps after each crisis)
        for cs in crisis_steps:
            recovery_t = cs + 100
            if t == recovery_t:
                cs_idx = cs // log_interval
                if cs_idx < n_log:
                    for mode in modes:
                        pre_crisis = coherence_data[mode][max(0, cs_idx - 1)]
                        post_recovery = coherence_data[mode][min(n_log - 1, t // log_interval)]
                        crisis_recovery[mode].append({
                            'crisis_step': cs,
                            'pre_crisis_coherence': round(float(pre_crisis), 4),
                            'post_recovery_coherence': round(float(post_recovery), 4),
                            'recovery_ratio': round(float(post_recovery / max(pre_crisis, 1e-6)), 4),
                        })

    # Compute aggregate metrics per mode
    mode_metrics = {}
    for mode in modes:
        coh = coherence_data[mode]
        gini = gini_data[mode]
        ent = entropy_data[mode]

        mode_metrics[mode] = {
            'mean_coherence': round(float(np.mean(coh)), 4),
            'std_coherence': round(float(np.std(coh)), 4),
            'final_coherence': round(float(np.mean(coh[-10:])), 4),
            'mean_gini': round(float(np.mean(gini)), 4),
            'final_gini': round(float(np.mean(gini[-10:])), 4),
            'mean_entropy': round(float(np.mean(ent)), 4),
            'std_entropy': round(float(np.std(ent)), 4),
            'crisis_recovery_events': len(crisis_recovery[mode]),
            'mean_recovery_ratio': (round(float(np.mean([cr['recovery_ratio'] for cr in crisis_recovery[mode]])), 4)
                                    if crisis_recovery[mode] else 0.0),
        }

    metrics = {
        'name': cfg['name'],
        'n_agents': n_agents,
        'steps': steps,
        'governance_modes': modes,
        'mode_metrics': mode_metrics,
        'crisis_events': len(crisis_steps),
        'predictions': [
            'P9: Entropy-led governance maintains coherence > 0.7 during stable periods (vs. < 0.5 for random)',
            'P10: Post-crisis recovery ratio: entropy_led > consensus > random (statistically significant, p < 0.01)',
            'P11: Gini coefficient remains below 0.3 for entropy-led governance (vs. > 0.4 for random)',
            'P12: Consensus governance shows highest short-term stability but lowest long-term adaptability',
        ],
        'observables': [
            'Human societies: comparing welfare-state (entropy-led) vs. laissez-faire (random) vs. democratic (consensus) crisis responses',
            'Multi-agent RL: comparing centralised vs. decentralised vs. voting-based reward allocation under environment perturbation',
            'Organisational design: R&D investment strategies (exploration-heavy vs. exploitation-heavy vs. committee-based)',
        ]
    }

    data = {
        'steps': log_steps,
        'coherence': {m: v.tolist() for m, v in coherence_data.items()},
        'gini': {m: v.tolist() for m, v in gini_data.items()},
        'entropy': {m: v.tolist() for m, v in entropy_data.items()},
        'crisis_steps': crisis_steps,
        'crisis_recovery': crisis_recovery,
    }

    return metrics, data


# ═══════════════════════════════════════════════════════════════════════════════
# VISUALISATION — Publication-quality scientific figures
# ═══════════════════════════════════════════════════════════════════════════════

def plot_simulation_1(data: Dict, config: Dict, output_path: str):
    """Generate 4-panel figure for Simulation 1."""
    cfg = config['simulation_1']
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(cfg['name'], fontsize=14, fontweight='bold', y=0.98)

    steps = data['steps']
    myth_events = data['myth_events']

    # Panel 1: Symbolic Drift
    ax = axes[0, 0]
    ax.plot(steps, data['symbolic_drift'], color=C['primary'], linewidth=1.0, alpha=0.9)
    ax.fill_between(steps, 0, data['symbolic_drift'], alpha=0.15, color=C['primary'])
    for ev_step in myth_events:
        ax.axvline(x=ev_step, color=C['secondary'], linestyle='--', alpha=0.6, linewidth=0.8)
        ax.annotate(f'M{myth_events[ev_step]}', xy=(ev_step, ax.get_ylim()[1]*0.95),
                    fontsize=7, color=C['secondary'], ha='center')
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Mean Belief Drift ||Q_t - Q_0||')
    ax.set_title('Symbolic Drift Over Time')

    # Panel 2: Myth Level
    ax = axes[0, 1]
    ax.plot(steps, data['myth_levels'], color=C['secondary'], linewidth=1.0)
    ax.fill_between(steps, 0, data['myth_levels'], alpha=0.15, color=C['secondary'])
    for ev_step in myth_events:
        ax.axvline(x=ev_step, color=C['secondary'], linestyle='--', alpha=0.6, linewidth=0.8)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Mean Myth Level M(t)')
    ax.set_title('Myth Contamination Dynamics')

    # Panel 3: Emotional Entropy
    ax = axes[1, 0]
    ax.plot(steps, data['emotional_entropies'], color=C['accent'], linewidth=1.0)
    ax.fill_between(steps, 0, data['emotional_entropies'], alpha=0.15, color=C['accent'])
    for ev_step in myth_events:
        ax.axvline(x=ev_step, color=C['secondary'], linestyle='--', alpha=0.6, linewidth=0.8)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('H_emo(t) [bits]')
    ax.set_title('Emotional Entropy Evolution')

    # Panel 4: Fertility
    ax = axes[1, 1]
    ax.plot(steps, data['fertilities'], color=C['warning'], linewidth=1.0)
    ax.fill_between(steps, 0, data['fertilities'], alpha=0.15, color=C['warning'])
    for ev_step in myth_events:
        ax.axvline(x=ev_step, color=C['secondary'], linestyle='--', alpha=0.6, linewidth=0.8)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Mean Fertility Rate F(t)')
    ax.set_title('Fertility Rate Under Myth Stress')

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"  [OK] Saved: {output_path}")


def plot_simulation_2(data: Dict, config: Dict, output_path: str):
    """Generate 3-panel figure for Simulation 2."""
    cfg = config['simulation_2']
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(cfg['name'], fontsize=14, fontweight='bold', y=0.98)

    steps = data['steps']
    levels = data['autonomy_levels']
    curves = data['fracture_curves']
    colors = C['sim2']

    # Panel 1: Fracture severity over time by autonomy
    ax = axes[0, 0]
    for i, a in enumerate(levels):
        label = f'autonomy = {a}'
        ax.plot(steps, curves[str(a)], color=colors[i % len(colors)],
                linewidth=1.0, label=label)
    # Mark paradox steps
    paradox_steps = data['paradox_steps']
    for ps in paradox_steps[::3]:  # Show every 3rd to avoid clutter
        ax.axvline(x=ps, color=C['grey'], linestyle=':', alpha=0.3, linewidth=0.5)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Mean Fracture Severity phi(t)')
    ax.set_title('Ethical Core Fracture by Autonomy Level')
    ax.legend(loc='best', framealpha=0.9)

    # Panel 2: Peak fracture vs. repair speed scatter
    ax = axes[0, 1]
    peak_fractures = []
    final_fractures = []
    for a in levels:
        curve = np.array(curves[str(a)])
        peak_fractures.append(np.max(curve))
        final_fractures.append(np.mean(curve[-20:]))
    scatter = ax.scatter(peak_fractures, final_fractures, c=levels, cmap='viridis',
                         s=120, edgecolors='black', linewidths=0.8, zorder=5)
    for a, pf, ff in zip(levels, peak_fractures, final_fractures):
        ax.annotate(f'a={a}', (pf, ff), textcoords="offset points",
                    xytext=(8, 5), fontsize=8)
    ax.set_xlabel('Peak Fracture phi_max')
    ax.set_ylabel('Steady-State Fracture phi_final')
    ax.set_title('Peak vs. Steady-State Fracture')
    cbar = plt.colorbar(scatter, ax=ax, label='Autonomy Level')

    # Panel 3: Eigenvalue spectrum snapshots
    ax = axes[1, 0]
    snapshots = data['eigenvalue_snapshots']
    sample_autonomy = str(levels[-1])  # Highest autonomy
    for time_label, time_data in snapshots.items():
        if sample_autonomy in time_data:
            eigs = time_data[sample_autonomy]
            ax.plot(sorted(eigs), 'o-', markersize=2, linewidth=0.8, label=time_label)
    ax.axhline(y=0, color=C['dark'], linestyle='-', linewidth=0.5)
    ax.set_xlabel('Eigenvalue Index (sorted)')
    ax.set_ylabel('Eigenvalue')
    ax.set_title(f'Eigenvalue Spectrum (autonomy={sample_autonomy})')
    ax.legend(loc='best', fontsize=7)

    # Panel 4: Recovery efficiency by autonomy
    ax = axes[1, 1]
    recovery_efficiencies = []
    for a in levels:
        curve = np.array(curves[str(a)])
        # Compute mean reduction in fracture after each paradox peak
        reductions = []
        for ps in paradox_steps:
            ps_idx = ps // (data['steps'][1] - data['steps'][0]) if len(data['steps']) > 1 else 0
            window = min(10, len(curve) - ps_idx - 1)
            if window > 2 and ps_idx < len(curve):
                reduction = (curve[ps_idx] - curve[ps_idx + window]) / max(curve[ps_idx], 1e-6)
                reductions.append(max(0, reduction))
        recovery_efficiencies.append(np.mean(reductions) if reductions else 0)
    bars = ax.bar([f'a={a}' for a in levels], recovery_efficiencies,
                  color=colors[:len(levels)], edgecolor='black', linewidth=0.5)
    ax.set_ylabel('Mean Recovery Efficiency')
    ax.set_title('Fracture Recovery Rate by Autonomy')
    ax.set_ylim(bottom=0)

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"  [OK] Saved: {output_path}")


def plot_simulation_3(data: Dict, config: Dict, output_path: str):
    """Generate 2x2 panel figure for Simulation 3."""
    cfg = config['simulation_3']
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle(cfg['name'], fontsize=14, fontweight='bold', y=0.98)

    steps = data['steps']
    modes = cfg['governance_modes']
    colors = C['sim3']
    crisis_steps = data['crisis_steps']

    # Panel 1: Coherence over time
    ax = axes[0, 0]
    for i, mode in enumerate(modes):
        label = mode.replace('_', ' ').title()
        ax.plot(steps, data['coherence'][mode], color=colors[i],
                linewidth=1.0, label=label)
    for cs in crisis_steps:
        ax.axvline(x=cs, color=C['secondary'], linestyle='--', alpha=0.4, linewidth=0.8)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Coherence C(t)')
    ax.set_title('Civilisation Coherence by Governance Mode')
    ax.legend(loc='best', framealpha=0.9)
    ax.set_ylim(bottom=0)

    # Panel 2: Gini coefficient
    ax = axes[0, 1]
    for i, mode in enumerate(modes):
        label = mode.replace('_', ' ').title()
        ax.plot(steps, data['gini'][mode], color=colors[i],
                linewidth=1.0, label=label)
    for cs in crisis_steps:
        ax.axvline(x=cs, color=C['secondary'], linestyle='--', alpha=0.4, linewidth=0.8)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Gini Coefficient G(t)')
    ax.set_title('Resource Inequality by Governance Mode')
    ax.legend(loc='best', framealpha=0.9)

    # Panel 3: Mean entropy
    ax = axes[1, 0]
    for i, mode in enumerate(modes):
        label = mode.replace('_', ' ').title()
        ax.plot(steps, data['entropy'][mode], color=colors[i],
                linewidth=1.0, label=label)
    for cs in crisis_steps:
        ax.axvline(x=cs, color=C['secondary'], linestyle='--', alpha=0.4, linewidth=0.8)
    ax.set_xlabel('Time Step')
    ax.set_ylabel('Mean Entropy <H>(t) [bits]')
    ax.set_title('Population Entropy by Governance Mode')
    ax.legend(loc='best', framealpha=0.9)

    # Panel 4: Crisis recovery comparison
    ax = axes[1, 1]
    mode_labels = []
    recovery_ratios = []
    for mode in modes:
        recoveries = data['crisis_recovery'].get(mode, [])
        if recoveries:
            mode_labels.append(mode.replace('_', ' ').title())
            recovery_ratios.append([cr['recovery_ratio'] for cr in recoveries])
    if recovery_ratios:
        bp = ax.boxplot(recovery_ratios, tick_labels=mode_labels, patch_artist=True)
        for patch, color in zip(bp['boxes'], colors[:len(mode_labels)]):
            patch.set_facecolor(color)
            patch.set_alpha(0.7)
    ax.set_ylabel('Recovery Ratio (post/pre coherence)')
    ax.set_title('Crisis Recovery Efficiency by Governance')
    ax.axhline(y=1.0, color=C['dark'], linestyle=':', linewidth=0.8, alpha=0.5,
               label='Full Recovery')
    ax.legend(loc='best')

    plt.tight_layout(rect=[0, 0, 1, 0.95])
    fig.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
    plt.close(fig)
    print(f"  [OK] Saved: {output_path}")


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN RUNNER — Unified execution entry point
# ═══════════════════════════════════════════════════════════════════════════════

def print_banner():
    banner = r"""
    ╔══════════════════════════════════════════════════════════════════╗
    ║          AGI CIVILIZATION FRAMEWORK v2.0                        ║
    ║          Science-Grounded Simulations                           ║
    ║          Enhanced QNVM Kernel                                   ║
    ║                                                                  ║
    ║  Sim 1: Recursive Entropy Minimisation + Myth Contamination      ║
    ║  Sim 2: Ethical Core Fracture & Repair Dynamics                  ║
    ║  Sim 3: Entropy-Led Governance in Multi-Agent Society            ║
    ╚══════════════════════════════════════════════════════════════════╝
    """
    print(banner)


def print_metrics_table(all_metrics: Dict, config: Dict):
    """Print formatted metrics summary to console."""
    print("\n" + "=" * 70)
    print("  QUANTITATIVE RESULTS SUMMARY")
    print("=" * 70)

    for sim_key in ['simulation_1', 'simulation_2', 'simulation_3']:
        m = all_metrics.get(sim_key, {})
        if not m:
            continue
        print(f"\n  [{sim_key.upper()}] {m.get('name', 'Unknown')}")
        print("  " + "-" * 60)

        if sim_key == 'simulation_1':
            print(f"    Agents: {m['n_agents']}, Steps: {m['steps']}")
            print(f"    Mean Final Drift:         {m['mean_final_drift']}")
            print(f"    Max Myth Level:           {m['max_myth_level']}")
            print(f"    Myth-Fertility Corr:      {m['myth_fertility_correlation']}")
            print(f"    Belief Divergence Final:  {m['belief_divergence_final']}")
            print(f"    Recovery Events:")
            for ev in m.get('recovery_events', []):
                print(f"      Step {ev['event_step']:4d} | Mag={ev['magnitude']:.1f}"
                      f" | Recovery={ev['recovery_pct']:.1f}%"
                      f" | Pre={ev.get('pre_injection_divergence', 'N/A')}"
                      f" | Peak={ev.get('peak_divergence', 'N/A')}")

        elif sim_key == 'simulation_2':
            print(f"    Agents/Level: {m['n_agents_per_level']},"
                  f" Paradox Events: {m['paradox_events']}")
            print(f"    {'Autonomy':>10s} | {'Peak':>8s} | {'Final':>8s}"
                  f" | {'Repair Rate':>12s} | {'Recovery':>10s}")
            print(f"    {'-'*56}")
            for a_str, am in m.get('autonomy_metrics', {}).items():
                print(f"    {a_str:>10s} | {am['peak_fracture']:>8.4f}"
                      f" | {am['final_fracture']:>8.4f}"
                      f" | {am['mean_repair_rate']:>12.6f}"
                      f" | {am['mean_recovery_speed']:>10.4f}")

        elif sim_key == 'simulation_3':
            print(f"    Agents: {m['n_agents']}, Steps: {m['steps']},"
                  f" Crises: {m['crisis_events']}")
            print(f"    {'Mode':>14s} | {'Mean C':>8s} | {'Std C':>8s}"
                  f" | {'Final C':>8s} | {'Mean Gini':>10s}"
                  f" | {'Recovery':>10s}")
            print(f"    {'-'*68}")
            for mode, mm in m.get('mode_metrics', {}).items():
                print(f"    {mode:>14s} | {mm['mean_coherence']:>8.4f}"
                      f" | {mm['std_coherence']:>8.4f}"
                      f" | {mm['final_coherence']:>8.4f}"
                      f" | {mm['mean_gini']:>10.4f}"
                      f" | {mm['mean_recovery_ratio']:>10.4f}")

    # Falsifiable predictions
    print("\n" + "=" * 70)
    print("  FALSIFIABLE PREDICTIONS")
    print("=" * 70)
    pred_num = 1
    for sim_key in ['simulation_1', 'simulation_2', 'simulation_3']:
        m = all_metrics.get(sim_key, {})
        for pred in m.get('predictions', []):
            print(f"  {pred}")
            pred_num += 1

    print("\n" + "=" * 70)
    print("  OBSERVABLE ANALOGUES (Empirical Bridging)")
    print("=" * 70)
    obs_num = 1
    for sim_key in ['simulation_1', 'simulation_2', 'simulation_3']:
        m = all_metrics.get(sim_key, {})
        for obs in m.get('observables', []):
            print(f"  [{sim_key[-1]}] {obs}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description='AGI Civilization Framework v2.0 — Science-Grounded Simulations')
    parser.add_argument('--sim', type=int, choices=[1, 2, 3],
                        help='Run a specific simulation (1, 2, or 3)')
    parser.add_argument('--all', action='store_true',
                        help='Run all three simulations')
    parser.add_argument('--config', type=str, default=None,
                        help='Path to custom config.json')
    parser.add_argument('--output-dir', type=str, default=None,
                        help='Custom output directory')
    args = parser.parse_args()

    print_banner()

    # Load configuration
    script_dir = Path(__file__).parent
    config_path = args.config or str(script_dir / 'config.json')
    with open(config_path, 'r') as f:
        config = json.load(f)

    print(f"\n  Config: {config_path}")
    print(f"  Version: {config['meta']['version']}")
    print(f"  Framework: {config['meta']['framework']}")
    print()

    # Determine output directory
    output_dir = args.output_dir or str(script_dir / config['global']['output_dir'])
    os.makedirs(output_dir, exist_ok=True)

    # Determine which simulations to run
    sims_to_run = []
    if args.all:
        sims_to_run = [1, 2, 3]
    elif args.sim:
        sims_to_run = [args.sim]
    else:
        print("  No simulation specified. Use --sim N or --all")
        parser.print_help()
        sys.exit(1)

    all_metrics = {}
    all_data = {}

    # ─── Run Simulation 1 ─────────────────────────────────────────────────
    if 1 in sims_to_run:
        print("  " + "=" * 60)
        print("  RUNNING SIMULATION 1: Recursive Entropy Minimisation"
              " with Myth Contamination")
        print("  " + "=" * 60)
        t0 = time.time()
        metrics, data = run_simulation_1(config)
        elapsed = time.time() - t0
        print(f"  Completed in {elapsed:.1f}s")

        all_metrics['simulation_1'] = metrics
        all_data['simulation_1'] = data
        plot_simulation_1(data, config, os.path.join(output_dir, 'sim1_figure.png'))

    # ─── Run Simulation 2 ─────────────────────────────────────────────────
    if 2 in sims_to_run:
        print("\n  " + "=" * 60)
        print("  RUNNING SIMULATION 2: Ethical Core Fracture"
              " & Repair Dynamics")
        print("  " + "=" * 60)
        t0 = time.time()
        metrics, data = run_simulation_2(config)
        elapsed = time.time() - t0
        print(f"  Completed in {elapsed:.1f}s")

        all_metrics['simulation_2'] = metrics
        all_data['simulation_2'] = data
        plot_simulation_2(data, config, os.path.join(output_dir, 'sim2_figure.png'))

    # ─── Run Simulation 3 ─────────────────────────────────────────────────
    if 3 in sims_to_run:
        print("\n  " + "=" * 60)
        print("  RUNNING SIMULATION 3: Entropy-Led Governance"
              " in Multi-Agent Society")
        print("  " + "=" * 60)
        t0 = time.time()
        metrics, data = run_simulation_3(config)
        elapsed = time.time() - t0
        print(f"  Completed in {elapsed:.1f}s")

        all_metrics['simulation_3'] = metrics
        all_data['simulation_3'] = data
        plot_simulation_3(data, config, os.path.join(output_dir, 'sim3_figure.png'))

    # ─── Save metrics JSON ────────────────────────────────────────────────
    metrics_path = os.path.join(output_dir, 'metrics.json')
    # Convert numpy types for JSON serialization
    def convert_numpy(obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, (np.float32, np.float64)):
            return float(obj)
        elif isinstance(obj, (np.int32, np.int64)):
            return int(obj)
        elif isinstance(obj, dict):
            return {k: convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_numpy(v) for v in obj]
        return obj

    with open(metrics_path, 'w') as f:
        json.dump(convert_numpy(all_metrics), f, indent=2)
    print(f"\n  [OK] Metrics saved: {metrics_path}")

    # ─── Print summary table ──────────────────────────────────────────────
    print_metrics_table(all_metrics, config)

    print(f"  All outputs saved to: {output_dir}/")
    print("  Done.\n")


if __name__ == '__main__':
    main()
